# Provo Contracts

A marketplace for Provo students to sell or sublease housing contracts: a swipe matcher, a map, a "list your contract" form, and in-app messaging. It runs locally on your machine.

## Run it

Needs Node.js 22 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:3000. To try it on your phone, connect to the same Wi-Fi and open `http://<your-mac's-IP>:3000` (find the IP in System Settings > Wi-Fi > Details).

The first time it starts, it creates `data/app.db` (SQLite) with 10 Provo complexes and 12 **sample** listings so the matcher and map aren't empty. Uploaded photos go in `data/uploads/`.

- **The first account you sign up becomes the admin.** The Admin page lets you fix complex map pins, edit complex details, and delete all sample listings.
- `npm run reset-db` deletes the database so the next start reseeds it.

## What's where

| Page | File |
| --- | --- |
| Home | `src/app/page.tsx` |
| Filter quiz | `src/app/find/page.tsx` |
| Swipe matcher | `src/app/match/` |
| Map | `src/app/map/` (Leaflet + OpenStreetMap tiles) |
| Listing detail | `src/app/listings/[id]/` |
| List your contract | `src/app/sell/` |
| Inbox and chat | `src/app/inbox/` |
| My listings and saved | `src/app/me/page.tsx` |
| Admin | `src/app/admin/` |

Logic lives in `src/lib/`: `db.ts` (schema), `seed.ts` (sample data), `listings.ts` (search and match scoring), `filters.ts`, `actions.ts` (every form and button that changes data), `auth.ts` (email and password sessions).

## Known limits of v1

- Complex map pins are approximate until fixed on the Admin page, and BYU-approved flags should be checked.
- Walk times are estimated from straight-line distance to the middle of campus.
- Messages refresh every 4 seconds; there are no email or text notifications yet.
- No password reset and no email verification. A BYU or UVU email gets a "Student" badge without being verified.
- Built for one machine. Hosting it online (and moving SQLite to Postgres) is the v2 step.
