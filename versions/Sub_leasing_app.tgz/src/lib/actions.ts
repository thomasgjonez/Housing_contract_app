"use server";

import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db, UPLOAD_DIR } from "./db";
import {
  checkPassword,
  currentUser,
  endSession,
  hashPassword,
  isSchoolEmail,
  requireUser,
  startSession,
} from "./auth";
import { filtersToQuery, parseFilters } from "./filters";

export type FormState = { error?: string } | undefined;

function str(fd: FormData, key: string) {
  const v = fd.get(key);
  return typeof v === "string" ? v.trim() : "";
}

function safeNext(next: string) {
  return next.startsWith("/") && !next.startsWith("//") ? next : "/";
}

// ---------- accounts ----------

export async function signup(_: FormState, fd: FormData): Promise<FormState> {
  const name = str(fd, "name");
  const email = str(fd, "email").toLowerCase();
  const password = str(fd, "password");
  if (!name || !email || password.length < 8) {
    return { error: "Enter your name, an email, and a password of at least 8 characters." };
  }
  if (db.prepare("SELECT 1 FROM users WHERE email = ?").get(email)) {
    return { error: "That email already has an account. Try logging in." };
  }
  // The first real account becomes the admin (sample seller is user 1).
  const { n } = db.prepare("SELECT count(*) AS n FROM users WHERE password_hash NOT LIKE '!%'").get() as { n: number };
  const res = db
    .prepare(
      "INSERT INTO users (name, email, password_hash, school_email_verified, is_admin) VALUES (?, ?, ?, ?, ?)"
    )
    .run(name, email, hashPassword(password), isSchoolEmail(email) ? 1 : 0, n === 0 ? 1 : 0);
  await startSession(Number(res.lastInsertRowid));
  redirect(safeNext(str(fd, "next")));
}

export async function login(_: FormState, fd: FormData): Promise<FormState> {
  const email = str(fd, "email").toLowerCase();
  const user = db.prepare("SELECT id, password_hash FROM users WHERE email = ?").get(email) as
    | { id: number; password_hash: string }
    | undefined;
  if (!user || !checkPassword(str(fd, "password"), user.password_hash)) {
    return { error: "Email or password is wrong." };
  }
  await startSession(user.id);
  redirect(safeNext(str(fd, "next")));
}

export async function logout() {
  await endSession();
  redirect("/");
}

// ---------- buyer ----------

export async function saveSearch(fd: FormData) {
  const params = new URLSearchParams();
  for (const [k, v] of fd.entries()) if (typeof v === "string" && v) params.append(k, v);
  const query = filtersToQuery(parseFilters(params));
  const user = await currentUser();
  if (user) {
    db.prepare(
      `INSERT INTO saved_searches (user_id, query) VALUES (?, ?)
       ON CONFLICT(user_id) DO UPDATE SET query = excluded.query, updated_at = datetime('now')`
    ).run(user.id, query);
  }
  const view = str(fd, "view") === "map" ? "map" : "match";
  redirect(`/${view}${query ? `?${query}` : ""}`);
}

export async function swipe(listingId: number, direction: "like" | "skip") {
  const user = await currentUser();
  if (!user) return { saved: false };
  db.prepare(
    `INSERT INTO swipes (user_id, listing_id, direction) VALUES (?, ?, ?)
     ON CONFLICT(user_id, listing_id) DO UPDATE SET direction = excluded.direction, created_at = datetime('now')`
  ).run(user.id, listingId, direction);
  return { saved: true };
}

export async function resetSkips() {
  const user = await currentUser();
  if (user) db.prepare("DELETE FROM swipes WHERE user_id = ? AND direction = 'skip'").run(user.id);
  revalidatePath("/match");
}

export async function unsave(listingId: number) {
  const user = await requireUser("/me");
  db.prepare("DELETE FROM swipes WHERE user_id = ? AND listing_id = ?").run(user.id, listingId);
  revalidatePath("/me");
}

// ---------- messaging ----------

export async function contactSeller(fd: FormData) {
  const listingId = Number(str(fd, "listingId"));
  const user = await requireUser(`/listings/${listingId}`);
  const listing = db.prepare("SELECT seller_id FROM listings WHERE id = ?").get(listingId) as
    | { seller_id: number }
    | undefined;
  if (!listing || listing.seller_id === user.id) redirect(`/listings/${listingId}`);
  db.prepare(
    "INSERT OR IGNORE INTO conversations (listing_id, buyer_id, seller_id) VALUES (?, ?, ?)"
  ).run(listingId, user.id, listing.seller_id);
  // Saving the listing too, so it shows up under Saved.
  db.prepare("INSERT OR REPLACE INTO swipes (user_id, listing_id, direction) VALUES (?, ?, 'like')").run(
    user.id,
    listingId
  );
  const conv = db
    .prepare("SELECT id FROM conversations WHERE listing_id = ? AND buyer_id = ?")
    .get(listingId, user.id) as { id: number };
  const body = str(fd, "body");
  if (body) {
    db.prepare("INSERT INTO messages (conversation_id, sender_id, body) VALUES (?, ?, ?)").run(conv.id, user.id, body);
  }
  redirect(`/inbox/${conv.id}`);
}

export async function sendMessage(fd: FormData) {
  const convId = Number(str(fd, "conversationId"));
  const user = await requireUser(`/inbox/${convId}`);
  const body = str(fd, "body");
  const conv = db
    .prepare("SELECT id FROM conversations WHERE id = ? AND (buyer_id = ? OR seller_id = ?)")
    .get(convId, user.id, user.id);
  if (conv && body) {
    db.prepare("INSERT INTO messages (conversation_id, sender_id, body) VALUES (?, ?, ?)").run(convId, user.id, body.slice(0, 4000));
  }
  revalidatePath(`/inbox/${convId}`);
}

// ---------- seller ----------

const IMAGE_TYPES: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "image/gif": ".gif",
};

export async function createListing(_: FormState, fd: FormData): Promise<FormState> {
  const user = await currentUser();
  if (!user) return { error: "Log in first so buyers can message you." };

  let complexId = Number(str(fd, "complexId"));
  if (str(fd, "complexId") === "other") {
    const name = str(fd, "newComplexName");
    const lat = Number(str(fd, "lat"));
    const lng = Number(str(fd, "lng"));
    if (!name) return { error: "Enter the name of your complex." };
    if (!lat || !lng) return { error: "Tap the map to place your complex." };
    const existing = db.prepare("SELECT id FROM complexes WHERE name = ? COLLATE NOCASE").get(name) as
      | { id: number }
      | undefined;
    complexId = existing
      ? existing.id
      : Number(
          db
            .prepare("INSERT INTO complexes (name, address, lat, lng, byu_approved) VALUES (?, ?, ?, ?, ?)")
            .run(name, str(fd, "newComplexAddress") || null, lat, lng, fd.get("newComplexApproved") ? 1 : 0)
            .lastInsertRowid
        );
  }
  if (!complexId || !db.prepare("SELECT 1 FROM complexes WHERE id = ?").get(complexId)) {
    return { error: "Pick your complex." };
  }

  const rent = Number(str(fd, "rent"));
  const start = str(fd, "startDate");
  const end = str(fd, "endDate");
  const gender = str(fd, "gender");
  const room = str(fd, "room");
  const term = str(fd, "term");
  if (!["men", "women", "coed"].includes(gender)) return { error: "Pick men's, women's or coed housing." };
  if (!["private", "shared"].includes(room)) return { error: "Pick private or shared room." };
  if (!["fall-winter", "spring-summer", "full-year", "other"].includes(term)) return { error: "Pick the contract term." };
  if (!rent || rent < 50 || rent > 5000) return { error: "Enter the monthly rent in dollars." };
  if (!start || !end || end <= start) return { error: "Enter a start date and an end date after it." };

  const files = fd.getAll("photos").filter((f): f is File => f instanceof File && f.size > 0).slice(0, 8);
  for (const f of files) {
    if (!IMAGE_TYPES[f.type]) return { error: `${f.name} is not a JPG, PNG, WebP or GIF image.` };
    if (f.size > 8 * 1024 * 1024) return { error: `${f.name} is over 8 MB.` };
  }

  const source = user.is_admin && fd.get("seeded") ? "seeded" : "user";
  const deposit = Number(str(fd, "deposit")) || null;
  const res = db
    .prepare(
      `INSERT INTO listings (seller_id, complex_id, unit, housing_gender, room_type, rent_monthly, deposit,
        utilities_included, start_date, end_date, contract_term, incentive, parking, description, contact_note, source)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      user.id, complexId, str(fd, "unit") || null, gender, room, Math.round(rent), deposit,
      fd.get("utilities") ? 1 : 0, start, end, term, str(fd, "incentive") || null,
      fd.get("parking") ? 1 : 0, str(fd, "description") || null, str(fd, "contactNote") || null, source
    );
  const listingId = Number(res.lastInsertRowid);

  const addPhoto = db.prepare("INSERT INTO photos (listing_id, file, position) VALUES (?, ?, ?)");
  let i = 0;
  for (const f of files) {
    const name = `${listingId}-${crypto.randomBytes(8).toString("hex")}${IMAGE_TYPES[f.type]}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, name), Buffer.from(await f.arrayBuffer()));
    addPhoto.run(listingId, name, i++);
  }

  const phone = str(fd, "phone");
  if (phone) db.prepare("UPDATE users SET phone = ? WHERE id = ?").run(phone, user.id);

  revalidatePath("/", "layout");
  redirect(`/listings/${listingId}?posted=1`);
}

async function ownListing(listingId: number) {
  const user = await requireUser("/me");
  const ok = db
    .prepare("SELECT 1 FROM listings WHERE id = ? AND (seller_id = ? OR ? = 1)")
    .get(listingId, user.id, user.is_admin);
  if (!ok) throw new Error("Not your listing");
}

export async function setListingStatus(fd: FormData) {
  const id = Number(str(fd, "listingId"));
  const status = str(fd, "status");
  if (!["active", "pending", "sold"].includes(status)) return;
  await ownListing(id);
  db.prepare("UPDATE listings SET status = ? WHERE id = ?").run(status, id);
  revalidatePath("/", "layout");
}

export async function bumpListing(fd: FormData) {
  const id = Number(str(fd, "listingId"));
  await ownListing(id);
  db.prepare("UPDATE listings SET bumped_at = datetime('now') WHERE id = ?").run(id);
  revalidatePath("/", "layout");
}

// ---------- admin ----------

async function requireAdmin() {
  const user = await requireUser("/admin");
  if (!user.is_admin) redirect("/");
  return user;
}

export async function moveComplex(complexId: number, lat: number, lng: number) {
  await requireAdmin();
  db.prepare("UPDATE complexes SET lat = ?, lng = ?, location_verified = 1 WHERE id = ?").run(lat, lng, complexId);
  revalidatePath("/", "layout");
}

export async function updateComplex(fd: FormData) {
  await requireAdmin();
  db.prepare(
    "UPDATE complexes SET name = ?, byu_approved = ?, management_company = ?, pms = ? WHERE id = ?"
  ).run(
    str(fd, "name"),
    fd.get("byuApproved") ? 1 : 0,
    str(fd, "managementCompany") || null,
    str(fd, "pms") || null,
    Number(str(fd, "id"))
  );
  revalidatePath("/", "layout");
}

export async function deleteSamples() {
  await requireAdmin();
  db.prepare("DELETE FROM listings WHERE source = 'sample'").run();
  revalidatePath("/", "layout");
}
