import "server-only";
import { db } from "./db";
import type { Filters } from "./filters";

// Roughly the middle of BYU campus.
export const CAMPUS = { lat: 40.2518, lng: -111.6493 };

export type Listing = {
  id: number;
  seller_id: number;
  complex_id: number;
  complex: string;
  lat: number;
  lng: number;
  byu_approved: number;
  unit: string | null;
  housing_gender: "men" | "women" | "coed";
  room_type: "private" | "shared";
  rent_monthly: number;
  deposit: number | null;
  utilities_included: number;
  start_date: string;
  end_date: string;
  contract_term: string;
  incentive: string | null;
  parking: number;
  description: string | null;
  contact_note: string | null;
  status: string;
  source: string;
  created_at: string;
  photo: string | null;
  walk_minutes: number;
};

export type ScoredListing = Listing & { score: number; reasons: string[] };

const BASE = `
  SELECT l.*, c.name AS complex, c.lat, c.lng, c.byu_approved,
    (SELECT file FROM photos p WHERE p.listing_id = l.id ORDER BY position LIMIT 1) AS photo
  FROM listings l JOIN complexes c ON c.id = l.complex_id`;

// Straight-line distance to campus, padded for streets, at a 80 m/min walk.
export function walkMinutes(lat: number, lng: number) {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat - CAMPUS.lat);
  const dLng = toRad(lng - CAMPUS.lng);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(CAMPUS.lat)) * Math.cos(toRad(lat)) * Math.sin(dLng / 2) ** 2;
  const meters = 2 * R * Math.asin(Math.sqrt(a));
  return Math.max(1, Math.round((meters * 1.3) / 80));
}

function withWalk(rows: Omit<Listing, "walk_minutes">[]): Listing[] {
  return rows.map((r) => ({ ...r, walk_minutes: walkMinutes(r.lat, r.lng) }));
}

export function getListing(id: number): Listing | null {
  const row = db.prepare(`${BASE} WHERE l.id = ?`).get(id) as Omit<Listing, "walk_minutes"> | undefined;
  return row ? withWalk([row])[0] : null;
}

export function getPhotos(listingId: number): string[] {
  return (
    db.prepare("SELECT file FROM photos WHERE listing_id = ? ORDER BY position").all(listingId) as { file: string }[]
  ).map((p) => p.file);
}

export function listingsBySeller(sellerId: number): Listing[] {
  return withWalk(
    db.prepare(`${BASE} WHERE l.seller_id = ? ORDER BY l.created_at DESC`).all(sellerId) as Omit<Listing, "walk_minutes">[]
  );
}

export function likedListings(userId: number): Listing[] {
  return withWalk(
    db
      .prepare(
        `${BASE} JOIN swipes s ON s.listing_id = l.id
         WHERE s.user_id = ? AND s.direction = 'like' AND l.status IN ('active','pending')
         ORDER BY s.created_at DESC`
      )
      .all(userId) as Omit<Listing, "walk_minutes">[]
  );
}

export function recentListings(limit = 6): Listing[] {
  return withWalk(
    db.prepare(`${BASE} WHERE l.status = 'active' ORDER BY l.bumped_at DESC LIMIT ?`).all(limit) as Omit<
      Listing,
      "walk_minutes"
    >[]
  );
}

function monthEnd(ym: string) {
  const [y, m] = ym.split("-").map(Number);
  const d = new Date(Date.UTC(y, m, 0));
  return d.toISOString().slice(0, 10);
}

// Hard filters drop a listing; the score orders what is left so the best fit
// comes first in the swipe deck. Reasons are the "why this matches" chips.
export function searchListings(f: Filters, opts: { excludeSwipedBy?: number } = {}): ScoredListing[] {
  const where = ["l.status = 'active'"];
  const args: (string | number)[] = [];
  if (f.gender !== "any") {
    where.push("l.housing_gender IN (?, 'coed')");
    args.push(f.gender);
  }
  if (f.room !== "any") {
    where.push("l.room_type = ?");
    args.push(f.room);
  }
  if (f.term !== "any") {
    where.push("l.contract_term = ?");
    args.push(f.term);
  }
  if (f.maxRent) {
    where.push("l.rent_monthly <= ?");
    args.push(f.maxRent);
  }
  if (f.moveIn) {
    // Available by the end of the move-in month and still running after it starts.
    where.push("l.start_date <= ? AND l.end_date >= ?");
    args.push(monthEnd(f.moveIn), `${f.moveIn}-01`);
  }
  if (f.parking) where.push("l.parking = 1");
  if (f.approvedOnly) where.push("c.byu_approved = 1");
  if (opts.excludeSwipedBy) {
    where.push("l.id NOT IN (SELECT listing_id FROM swipes WHERE user_id = ?)");
    args.push(opts.excludeSwipedBy);
  }

  const rows = withWalk(
    db.prepare(`${BASE} WHERE ${where.join(" AND ")} ORDER BY l.bumped_at DESC`).all(...args) as Omit<
      Listing,
      "walk_minutes"
    >[]
  ).filter((l) => !f.maxWalk || l.walk_minutes <= f.maxWalk);

  return rows
    .map((l) => {
      let score = 50;
      const reasons: string[] = [];
      if (f.maxRent) {
        const under = f.maxRent - l.rent_monthly;
        score += Math.min(25, under / 10);
        if (under >= 25) reasons.push(`$${under} under budget`);
      }
      score += Math.max(0, 15 - l.walk_minutes);
      if (l.walk_minutes <= 10) reasons.push(`${l.walk_minutes} min walk`);
      if (l.incentive) {
        score += 10;
        reasons.push(l.incentive);
      }
      if (l.utilities_included) {
        score += 3;
        reasons.push("Utilities included");
      }
      if (l.parking && !f.parking) reasons.push("Parking included");
      if (f.moveIn && l.start_date.startsWith(f.moveIn)) {
        score += 5;
        reasons.push("Starts the month you want");
      }
      return { ...l, score: Math.round(score), reasons: reasons.slice(0, 3) };
    })
    .sort((a, b) => b.score - a.score);
}
