import Link from "next/link";
import { notFound } from "next/navigation";
import { currentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { getListing, getPhotos } from "@/lib/listings";
import { GENDER_LABEL, TERM_LABEL, dateLabel } from "@/lib/filters";
import { bumpListing, contactSeller, setListingStatus } from "@/lib/actions";
import { ListingPhoto } from "@/components/ListingPhoto";
import { StatusBadge } from "@/components/ListingCard";
import { CopyLink } from "./CopyLink";

export default async function ListingPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string>>;
}) {
  const { id } = await params;
  const { posted } = await searchParams;
  const l = getListing(Number(id));
  if (!l) notFound();
  const photos = getPhotos(l.id);
  const user = await currentUser();
  const isOwner = user && (user.id === l.seller_id || user.is_admin);
  const seller = db.prepare("SELECT name, school_email_verified FROM users WHERE id = ?").get(l.seller_id) as {
    name: string;
    school_email_verified: number;
  };
  const existing = user
    ? (db.prepare("SELECT id FROM conversations WHERE listing_id = ? AND buyer_id = ?").get(l.id, user.id) as { id: number } | undefined)
    : undefined;

  const facts: [string, string][] = [
    ["Rent", `$${l.rent_monthly}/month`],
    ["Deposit", l.deposit ? `$${l.deposit}` : "Not listed"],
    ["Utilities", l.utilities_included ? "Included" : "Not included"],
    ["Housing", `${GENDER_LABEL[l.housing_gender]}, ${l.room_type} room`],
    ["Contract", `${TERM_LABEL[l.contract_term]}, ${dateLabel(l.start_date)} to ${dateLabel(l.end_date)}`],
    ["Parking", l.parking ? "Included" : "No"],
    ["Walk to campus", `About ${l.walk_minutes} min`],
    ["BYU-approved", l.byu_approved ? "Yes" : "No"],
  ];
  if (l.unit) facts.splice(4, 0, ["Unit", l.unit]);

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      {posted && (
        <div className="card border-emerald-200 bg-emerald-50 p-5">
          <div className="font-bold text-emerald-900">Your contract is live 🎉</div>
          <p className="mt-1 text-sm text-emerald-900">
            Share this link in your Facebook housing group posts too. Buyers get photos, a map and a way to message you.
          </p>
          <CopyLink path={`/listings/${l.id}`} />
        </div>
      )}

      <div className={`grid gap-2 overflow-hidden rounded-2xl ${photos.length > 1 ? "sm:grid-cols-[2fr_1fr]" : ""}`}>
        <ListingPhoto photo={photos[0] ?? null} complex={l.complex} id={l.id} className="h-72 w-full sm:h-96" />
        {photos.length > 1 && (
        <div className="hidden grid-rows-2 gap-2 sm:grid">
          {photos.slice(1, 3).map((p) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img key={p} src={`/api/photos/${p}`} alt="" className="h-full w-full object-cover" />
          ))}
        </div>
        )}
      </div>
      {photos.length > 3 && (
        <div className="flex gap-2 overflow-x-auto">
          {photos.slice(3).map((p) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img key={p} src={`/api/photos/${p}`} alt="" className="h-24 w-32 shrink-0 rounded-xl object-cover" />
          ))}
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-[1fr_320px]">
        <div className="space-y-5">
          <div>
            <div className="flex items-center gap-2"><StatusBadge status={l.status} source={l.source} /></div>
            <h1 className="mt-1 text-3xl font-extrabold">{l.complex}</h1>
            <div className="text-xl font-bold text-brand-700">${l.rent_monthly}/month</div>
            {l.incentive && <div className="mt-2 inline-block rounded-xl bg-emerald-50 px-3 py-1.5 text-sm font-semibold text-emerald-800">🎁 {l.incentive}</div>}
          </div>
          {l.description && <p className="whitespace-pre-line text-slate-700">{l.description}</p>}
          <dl className="card divide-y divide-slate-100">
            {facts.map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 px-4 py-3 text-sm">
                <dt className="text-slate-500">{k}</dt>
                <dd className="text-right font-medium">{v}</dd>
              </div>
            ))}
          </dl>
          <p className="text-xs text-slate-500">
            When you agree on a deal, the transfer is finished with {l.complex}&apos;s office. Ask them about their transfer fee before you pay anyone.
          </p>
        </div>

        <aside id="message" className="space-y-4">
          <div className="card space-y-3 p-5">
            <div className="text-sm text-slate-500">Listed by</div>
            <div className="font-semibold">
              {seller.name} {seller.school_email_verified ? <span className="ml-1 rounded-full bg-brand-50 px-2 py-0.5 text-xs text-brand-700">✓ Student</span> : null}
            </div>
            {l.contact_note && <p className="text-sm text-slate-600">{l.contact_note}</p>}
            {isOwner ? (
              <p className="text-sm text-slate-600">This is your listing.</p>
            ) : l.source === "sample" ? (
              <p className="text-sm text-amber-800">This is a sample listing to show how the app works.</p>
            ) : existing ? (
              <Link href={`/inbox/${existing.id}`} className="btn-primary w-full">Open your conversation</Link>
            ) : user ? (
              <form action={contactSeller} className="space-y-2">
                <input type="hidden" name="listingId" value={l.id} />
                <textarea name="body" required rows={3} className="input" defaultValue={`Hi! Is your ${l.complex} contract still available?`} />
                <button className="btn-primary w-full">Message seller</button>
              </form>
            ) : (
              <Link href={`/login?next=/listings/${l.id}`} className="btn-primary w-full">Log in to message</Link>
            )}
          </div>

          {isOwner && (
            <div className="card space-y-3 p-5">
              <div className="font-semibold">Manage listing</div>
              <form action={setListingStatus} className="flex flex-wrap gap-2">
                <input type="hidden" name="listingId" value={l.id} />
                {(["active", "pending", "sold"] as const).map((s) => (
                  <button key={s} name="status" value={s} disabled={l.status === s} className={l.status === s ? "btn-primary !py-1.5" : "btn-ghost !py-1.5"}>
                    {s === "active" ? "Active" : s === "pending" ? "Pending" : "Sold"}
                  </button>
                ))}
              </form>
              <form action={bumpListing}>
                <input type="hidden" name="listingId" value={l.id} />
                <button className="btn-ghost w-full !py-1.5">Bump to the top</button>
              </form>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
