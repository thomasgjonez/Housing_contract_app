import { currentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { parseFilters } from "@/lib/filters";
import { saveSearch } from "@/lib/actions";

function Choice({ name, value, label, checked }: { name: string; value: string; label: string; checked: boolean }) {
  return (
    <label className="cursor-pointer">
      <input type="radio" name={name} value={value} defaultChecked={checked} className="peer sr-only" />
      <span className="block rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-center text-sm font-medium peer-checked:border-brand-600 peer-checked:bg-brand-50 peer-checked:text-brand-700">
        {label}
      </span>
    </label>
  );
}

// Next 8 months as move-in options.
function months() {
  const out: { value: string; label: string }[] = [];
  const d = new Date();
  for (let i = 0; i < 9; i++) {
    const m = new Date(d.getFullYear(), d.getMonth() + i, 1);
    out.push({
      value: `${m.getFullYear()}-${String(m.getMonth() + 1).padStart(2, "0")}`,
      label: m.toLocaleString("en-US", { month: "long", year: "numeric" }),
    });
  }
  return out;
}

export default async function Find({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const sp = await searchParams;
  let f = parseFilters(sp);
  // Prefill from the buyer's last search when they arrive with no filters.
  const user = await currentUser();
  if (user && Object.keys(sp).filter((k) => k !== "view").length === 0) {
    const saved = db.prepare("SELECT query FROM saved_searches WHERE user_id = ?").get(user.id) as { query: string } | undefined;
    if (saved) f = parseFilters(new URLSearchParams(saved.query));
  }

  return (
    <form action={saveSearch} className="mx-auto max-w-xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">What are you looking for?</h1>
        <p className="text-slate-600">Leave anything blank if you don&apos;t care.</p>
      </div>

      <div className="card space-y-5 p-5">
        <div>
          <span className="label">Housing</span>
          <div className="grid grid-cols-3 gap-2">
            <Choice name="gender" value="women" label="Women's" checked={f.gender === "women"} />
            <Choice name="gender" value="men" label="Men's" checked={f.gender === "men"} />
            <Choice name="gender" value="any" label="Either" checked={f.gender === "any"} />
          </div>
        </div>
        <div>
          <span className="label">Room</span>
          <div className="grid grid-cols-3 gap-2">
            <Choice name="room" value="private" label="Private" checked={f.room === "private"} />
            <Choice name="room" value="shared" label="Shared" checked={f.room === "shared"} />
            <Choice name="room" value="any" label="Either" checked={f.room === "any"} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label>
            <span className="label">Max rent ($/month)</span>
            <input name="maxRent" type="number" min={0} step={25} defaultValue={f.maxRent ?? ""} placeholder="e.g. 550" className="input" />
          </label>
          <label>
            <span className="label">Move in by</span>
            <select name="moveIn" defaultValue={f.moveIn ?? ""} className="input">
              <option value="">Any time</option>
              {months().map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </label>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label>
            <span className="label">Contract</span>
            <select name="term" defaultValue={f.term} className="input">
              <option value="any">Any</option>
              <option value="fall-winter">Fall-Winter</option>
              <option value="spring-summer">Spring-Summer</option>
              <option value="full-year">Full year</option>
            </select>
          </label>
          <label>
            <span className="label">Max walk to campus</span>
            <select name="maxWalk" defaultValue={f.maxWalk ?? ""} className="input">
              <option value="">Any</option>
              <option value="5">5 min</option>
              <option value="10">10 min</option>
              <option value="15">15 min</option>
              <option value="20">20 min</option>
            </select>
          </label>
        </div>
        <div className="flex flex-wrap gap-5 text-sm">
          <label className="flex items-center gap-2"><input type="checkbox" name="parking" value="1" defaultChecked={f.parking} /> Need parking</label>
          <label className="flex items-center gap-2"><input type="checkbox" name="approvedOnly" value="1" defaultChecked={f.approvedOnly} /> BYU-approved only</label>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button name="view" value="match" className="btn-primary py-3">♥ Start swiping</button>
        <button name="view" value="map" className="btn-ghost py-3">◎ Show on map</button>
      </div>
    </form>
  );
}
