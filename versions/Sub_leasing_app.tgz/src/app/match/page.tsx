import { currentUser } from "@/lib/auth";
import { parseFilters } from "@/lib/filters";
import { searchListings } from "@/lib/listings";
import { FilterBar } from "@/components/FilterBar";
import { SwipeDeck } from "./SwipeDeck";

export default async function Match({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const filters = parseFilters(await searchParams);
  const user = await currentUser();
  const all = searchListings(filters);
  const deck = user ? searchListings(filters, { excludeSwipedBy: user.id }) : all;
  // The seller's own listings never show in their deck.
  const cards = deck.filter((l) => l.seller_id !== user?.id);

  return (
    <div>
      <FilterBar filters={filters} view="match" count={all.length} />
      <SwipeDeck key={cards.map((c) => c.id).join(",")} cards={cards} loggedIn={!!user} totalMatches={all.length} />
    </div>
  );
}
