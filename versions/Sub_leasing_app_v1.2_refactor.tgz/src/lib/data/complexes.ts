import "server-only";
import { db } from "../db";

export type Complex = {
  id: number;
  name: string;
  address: string | null;
  city: string;
  lat: number;
  lng: number;
  byu_approved: number;
  management_company: string | null;
  pms: string | null;
  website: string | null;
  location_verified: number;
};

export function allComplexes(): Complex[] {
  return db.prepare("SELECT * FROM complexes ORDER BY name").all() as Complex[];
}

export function complexOptions(): { id: number; name: string }[] {
  return db.prepare("SELECT id, name FROM complexes ORDER BY name").all() as { id: number; name: string }[];
}

export function complexExists(id: number) {
  return !!db.prepare("SELECT 1 FROM complexes WHERE id = ?").get(id);
}

/** Finds a complex by name, or adds it. Returns its id. */
export function findOrAddComplex(c: { name: string; address: string | null; lat: number; lng: number; byu_approved: number; city: string }) {
  const existing = db.prepare("SELECT id FROM complexes WHERE name = ? COLLATE NOCASE").get(c.name) as { id: number } | undefined;
  if (existing) return existing.id;
  return Number(
    db
      .prepare("INSERT INTO complexes (name, address, lat, lng, byu_approved, city) VALUES (@name, @address, @lat, @lng, @byu_approved, @city)")
      .run(c).lastInsertRowid
  );
}

export function moveComplexPin(id: number, lat: number, lng: number) {
  db.prepare("UPDATE complexes SET lat = ?, lng = ?, location_verified = 1 WHERE id = ?").run(lat, lng, id);
}

export function updateComplexDetails(
  id: number,
  c: { name: string; city: string; byu_approved: number; management_company: string | null; pms: string | null }
) {
  db.prepare(
    "UPDATE complexes SET name = @name, city = @city, byu_approved = @byu_approved, management_company = @management_company, pms = @pms WHERE id = @id"
  ).run({ ...c, id });
}
