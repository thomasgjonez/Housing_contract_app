import "server-only";
import { db } from "../db";
import { EXPIRE_AFTER_START_DAYS } from "../config";
import { walkMinutes } from "../geo";
import { rank, type BuyerPreferences, type MatchResult } from "../matching";

export type Listing = {
  id: number;
  seller_id: number;
  complex_id: number;
  complex: string;
  lat: number;
  lng: number;
  byu_approved: number;
  unit: string | null;
  housing_gender: "men" | "women" | "coed";
  room_type: "private" | "shared";
  rent_monthly: number;
  deposit: number | null;
  utilities_included: number;
  start_date: string;
  end_date: string;
  contract_term: string;
  incentive: string | null;
  parking: number;
  description: string | null;
  contact_note: string | null;
  status: string;
  source: string;
  created_at: string;
  photo: string | null;
  furnished: number;
  washer_dryer: string;
  private_bath: number;
  pets_allowed: number;
  city: string;
  walk_minutes: number;
};

export type ScoredListing = Listing & MatchResult;

type Row = Omit<Listing, "walk_minutes">;

const BASE = `
  SELECT l.*, c.name AS complex, c.lat, c.lng, c.byu_approved, c.city,
    (SELECT file FROM photos p WHERE p.listing_id = l.id ORDER BY position LIMIT 1) AS photo
  FROM listings l JOIN complexes c ON c.id = l.complex_id`;

function withWalk(rows: Row[]): Listing[] {
  return rows.map((r) => ({ ...r, walk_minutes: walkMinutes(r.lat, r.lng) }));
}

// ---------- expiry ----------

let lastExpiry = 0;

/**
 * Listings expire two weeks after the lease start date. Runs at most once a
 * minute, from the listing queries below, so nothing needs a scheduler.
 */
export function expireStaleListings(force = false) {
  if (!force && Date.now() - lastExpiry < 60_000) return 0;
  lastExpiry = Date.now();
  return db
    .prepare(
      `UPDATE listings SET status = 'expired'
       WHERE status IN ('active','pending') AND date(start_date, ?) < date('now')`
    )
    .run(`+${EXPIRE_AFTER_START_DAYS} days`).changes;
}

// ---------- reads ----------

export function getListing(id: number): Listing | null {
  expireStaleListings();
  const row = db.prepare(`${BASE} WHERE l.id = ?`).get(id) as Row | undefined;
  return row ? withWalk([row])[0] : null;
}

export function getPhotos(listingId: number): string[] {
  return (
    db.prepare("SELECT file FROM photos WHERE listing_id = ? ORDER BY position").all(listingId) as { file: string }[]
  ).map((p) => p.file);
}

export function listingsBySeller(sellerId: number): Listing[] {
  expireStaleListings();
  return withWalk(db.prepare(`${BASE} WHERE l.seller_id = ? ORDER BY l.created_at DESC`).all(sellerId) as Row[]);
}

export function likedListings(userId: number): Listing[] {
  expireStaleListings();
  return withWalk(
    db
      .prepare(
        `${BASE} JOIN swipes s ON s.listing_id = l.id
         WHERE s.user_id = ? AND s.direction = 'like' AND l.status IN ('active','pending')
         ORDER BY s.created_at DESC`
      )
      .all(userId) as Row[]
  );
}

export function recentListings(limit = 6): Listing[] {
  expireStaleListings();
  return withWalk(db.prepare(`${BASE} WHERE l.status = 'active' ORDER BY l.bumped_at DESC LIMIT ?`).all(limit) as Row[]);
}

export function activeListings(opts: { excludeSwipedBy?: number; excludeSeller?: number } = {}): Listing[] {
  expireStaleListings();
  const where = ["l.status = 'active'"];
  const args: number[] = [];
  if (opts.excludeSwipedBy) {
    where.push("l.id NOT IN (SELECT listing_id FROM swipes WHERE user_id = ?)");
    args.push(opts.excludeSwipedBy);
  }
  if (opts.excludeSeller) {
    where.push("l.seller_id != ?");
    args.push(opts.excludeSeller);
  }
  return withWalk(db.prepare(`${BASE} WHERE ${where.join(" AND ")} ORDER BY l.bumped_at DESC`).all(...args) as Row[]);
}

export function listingStats(listingId: number) {
  const saves = db.prepare("SELECT count(*) AS n FROM swipes WHERE listing_id = ? AND direction = 'like'").get(listingId) as { n: number };
  const chats = db.prepare("SELECT count(*) AS n FROM conversations WHERE listing_id = ?").get(listingId) as { n: number };
  return { saves: saves.n, chats: chats.n };
}

export function listingCounts() {
  return db.prepare("SELECT source, status, count(*) AS n FROM listings GROUP BY source, status").all() as {
    source: string;
    status: string;
    n: number;
  }[];
}

export function isListingOwner(listingId: number, userId: number) {
  return !!db.prepare("SELECT 1 FROM listings WHERE id = ? AND seller_id = ?").get(listingId, userId);
}

// ---------- matching ----------

/**
 * Ranked listings for a buyer's preferences (a saved profile, or quiz answers
 * from the URL). Pass userId to leave out their own listings and boost
 * complexes they liked; excludeSwiped also hides ones they already swiped.
 */
export function matchListings(
  p: BuyerPreferences,
  opts: { userId?: number; excludeSwiped?: boolean } = {}
): ScoredListing[] {
  const listings = activeListings({
    excludeSwipedBy: opts.excludeSwiped ? opts.userId : undefined,
    excludeSeller: opts.userId,
  });
  return rank(p, listings, { likedComplexIds: opts.userId ? likedComplexIds(opts.userId) : undefined });
}

function likedComplexIds(userId: number) {
  const rows = db
    .prepare(
      `SELECT DISTINCT l.complex_id AS id FROM swipes s JOIN listings l ON l.id = s.listing_id
       WHERE s.user_id = ? AND s.direction = 'like'`
    )
    .all(userId) as { id: number }[];
  return new Set(rows.map((r) => r.id));
}

// ---------- writes ----------

export type NewListing = {
  seller_id: number;
  complex_id: number;
  unit: string | null;
  housing_gender: string;
  room_type: string;
  rent_monthly: number;
  deposit: number | null;
  utilities_included: number;
  start_date: string;
  end_date: string;
  contract_term: string;
  incentive: string | null;
  parking: number;
  description: string | null;
  contact_note: string | null;
  source: "user" | "seeded";
  furnished: number;
  washer_dryer: string;
  private_bath: number;
  pets_allowed: number;
};

export function insertListing(l: NewListing, photos: string[]) {
  return db.transaction(() => {
    const keys = Object.keys(l) as (keyof NewListing)[];
    const id = Number(
      db
        .prepare(`INSERT INTO listings (${keys.join(", ")}) VALUES (${keys.map((k) => `@${k}`).join(", ")})`)
        .run(l).lastInsertRowid
    );
    const addPhoto = db.prepare("INSERT INTO photos (listing_id, file, position) VALUES (?, ?, ?)");
    photos.forEach((file, i) => addPhoto.run(id, file, i));
    return id;
  })();
}

export function setStatus(id: number, status: "active" | "pending" | "sold") {
  db.prepare("UPDATE listings SET status = ? WHERE id = ?").run(status, id);
}

export function bump(id: number) {
  db.prepare("UPDATE listings SET bumped_at = datetime('now') WHERE id = ?").run(id);
}

/** Puts an expired listing back up with new lease dates. */
export function relist(id: number, start: string, end: string) {
  db.prepare(
    "UPDATE listings SET status = 'active', start_date = ?, end_date = ?, bumped_at = datetime('now') WHERE id = ?"
  ).run(start, end, id);
}

export function deleteSampleListings() {
  db.prepare("DELETE FROM listings WHERE source = 'sample'").run();
}
