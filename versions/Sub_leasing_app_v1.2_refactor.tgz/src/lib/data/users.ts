import "server-only";
import { db } from "../db";

export function findUserByEmail(email: string) {
  return (
    (db.prepare("SELECT id, email, phone, password_hash FROM users WHERE lower(email) = lower(?)").get(email) as
      | { id: number; email: string; phone: string | null; password_hash: string }
      | undefined) ?? null
  );
}

export function createUser(u: { name: string; email: string; password_hash: string; school_email_verified: number; is_admin: number }) {
  return Number(
    db
      .prepare(
        "INSERT INTO users (name, email, password_hash, school_email_verified, is_admin) VALUES (@name, @email, @password_hash, @school_email_verified, @is_admin)"
      )
      .run(u).lastInsertRowid
  );
}

export function setPhone(userId: number, phone: string) {
  db.prepare("UPDATE users SET phone = ? WHERE id = ?").run(phone, userId);
}

export function publicSeller(userId: number) {
  return db.prepare("SELECT name, school_email_verified FROM users WHERE id = ?").get(userId) as {
    name: string;
    school_email_verified: number;
  };
}

/** Real accounts (not the sample seller). */
export function accountCount() {
  return (db.prepare("SELECT count(*) AS n FROM users WHERE password_hash NOT LIKE '!%'").get() as { n: number }).n;
}

// ---------- sessions ----------

export function createSession(token: string, userId: number) {
  db.prepare("INSERT INTO sessions (token, user_id) VALUES (?, ?)").run(token, userId);
}

export function deleteSession(token: string) {
  db.prepare("DELETE FROM sessions WHERE token = ?").run(token);
}

export function userForSession(token: string) {
  return db
    .prepare(
      `SELECT u.id, u.name, u.email, u.phone, u.school_email_verified, u.is_admin
       FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?`
    )
    .get(token);
}
