import "server-only";
import { db } from "../db";

export type InboxRow = {
  id: number;
  complex: string;
  rent_monthly: number;
  other_name: string;
  i_am_seller: number;
  last_body: string | null;
  last_at: string | null;
  unread: number;
};

export function inbox(userId: number): InboxRow[] {
  return db
    .prepare(
      `SELECT c.id, cx.name AS complex, l.rent_monthly,
         CASE WHEN c.seller_id = @me THEN b.name ELSE s.name END AS other_name,
         c.seller_id = @me AS i_am_seller,
         (SELECT body FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) AS last_body,
         (SELECT created_at FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) AS last_at,
         (SELECT count(*) FROM messages WHERE conversation_id = c.id AND sender_id != @me AND read_at IS NULL) AS unread
       FROM conversations c
       JOIN listings l ON l.id = c.listing_id
       JOIN complexes cx ON cx.id = l.complex_id
       JOIN users b ON b.id = c.buyer_id
       JOIN users s ON s.id = c.seller_id
       WHERE c.buyer_id = @me OR c.seller_id = @me
       ORDER BY coalesce(last_at, c.created_at) DESC`
    )
    .all({ me: userId }) as InboxRow[];
}

export type Conversation = {
  id: number;
  listing_id: number;
  buyer_id: number;
  seller_id: number;
  complex: string;
  rent_monthly: number;
  status: string;
  buyer_name: string;
  seller_name: string;
};

/** A conversation the user is part of, or null. */
export function getConversation(id: number, userId: number): Conversation | null {
  return (
    (db
      .prepare(
        `SELECT c.*, cx.name AS complex, l.rent_monthly, l.status, b.name AS buyer_name, s.name AS seller_name
         FROM conversations c JOIN listings l ON l.id = c.listing_id JOIN complexes cx ON cx.id = l.complex_id
         JOIN users b ON b.id = c.buyer_id JOIN users s ON s.id = c.seller_id
         WHERE c.id = ? AND (c.buyer_id = ? OR c.seller_id = ?)`
      )
      .get(id, userId, userId) as Conversation | undefined) ?? null
  );
}

export function conversationFor(listingId: number, buyerId: number) {
  return (
    (db.prepare("SELECT id FROM conversations WHERE listing_id = ? AND buyer_id = ?").get(listingId, buyerId) as
      | { id: number }
      | undefined) ?? null
  );
}

/** Opens (or reuses) the buyer's conversation about a listing. */
export function startConversation(listingId: number, buyerId: number, sellerId: number) {
  db.prepare("INSERT OR IGNORE INTO conversations (listing_id, buyer_id, seller_id) VALUES (?, ?, ?)").run(
    listingId,
    buyerId,
    sellerId
  );
  return conversationFor(listingId, buyerId)!.id;
}

export function messages(conversationId: number) {
  return db
    .prepare("SELECT id, sender_id, body, created_at FROM messages WHERE conversation_id = ? ORDER BY id")
    .all(conversationId) as { id: number; sender_id: number; body: string; created_at: string }[];
}

export function addMessage(conversationId: number, senderId: number, body: string) {
  db.prepare("INSERT INTO messages (conversation_id, sender_id, body) VALUES (?, ?, ?)").run(
    conversationId,
    senderId,
    body.slice(0, 4000)
  );
}

export function markRead(conversationId: number, userId: number) {
  db.prepare(
    "UPDATE messages SET read_at = datetime('now') WHERE conversation_id = ? AND sender_id != ? AND read_at IS NULL"
  ).run(conversationId, userId);
}

export function unreadCount(userId: number) {
  const row = db
    .prepare(
      `SELECT count(*) AS n FROM messages m JOIN conversations c ON c.id = m.conversation_id
       WHERE (c.buyer_id = ? OR c.seller_id = ?) AND m.sender_id != ? AND m.read_at IS NULL`
    )
    .get(userId, userId, userId) as { n: number };
  return row.n;
}
