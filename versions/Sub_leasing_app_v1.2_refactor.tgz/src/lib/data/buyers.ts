import "server-only";
import { db } from "../db";
import { resolveComplexNames } from "../db/schema";
import { activeListings, getListing } from "./listings";
import { ALERT_MIN_SCORE, scoreListing } from "../matching";
import { DEFAULT_PREFERENCES, type BuyerPreferences } from "../preferences";
import { sendMatchAlert } from "../notify";

/** Who the buyer is and how to reach them. */
export type BuyerContact = {
  name: string;
  email: string | null;
  phone: string | null;
  social: string | null;
  contact_method: string | null;
  school: string | null;
  contracts_needed: number;
  group_pref: string;
  takeover_ok: string;
  notes: string | null;
  alerts: "email" | "text" | "both" | "off";
};

export type ProfileInput = BuyerPreferences &
  BuyerContact & {
    active: number;
    complete: number;
    /** Complex names from the Google Form that matched no known complex. */
    unmatched_like?: string;
    unmatched_avoid?: string;
  };

export type BuyerProfile = ProfileInput & {
  id: number;
  user_id: number | null;
  source: "app" | "form";
  created_at: string;
  updated_at: string;
};

// Columns written from ProfileInput. Lists are stored comma-separated;
// favorite/avoid complexes live in buyer_complexes.
const COLUMNS = [
  "name", "email", "phone", "social", "contact_method", "school", "contracts_needed", "group_pref",
  "gender", "needs_approved", "move_in", "flex_days", "semesters", "term", "max_rent", "utilities",
  "room", "bath", "furnished", "washer", "areas", "distance", "parking", "pets", "takeover_ok",
  "notes", "alerts", "active", "complete", "like_complexes", "avoid_complexes",
] as const;

type Row = Omit<BuyerProfile, "semesters" | "areas" | "like_ids" | "avoid_ids" | "unmatched_like" | "unmatched_avoid"> & {
  semesters: string;
  areas: string;
  like_complexes: string;
  avoid_complexes: string;
};

const csv = (s: string) => (s ? s.split(",").map((x) => x.trim()).filter(Boolean) : []);

function hydrate(rows: Row[]): BuyerProfile[] {
  if (!rows.length) return [];
  const links = db
    .prepare(`SELECT profile_id, complex_id, kind FROM buyer_complexes WHERE profile_id IN (${rows.map(() => "?").join(",")})`)
    .all(...rows.map((r) => r.id)) as { profile_id: number; complex_id: number; kind: "like" | "avoid" }[];
  return rows.map(({ like_complexes, avoid_complexes, ...r }) => ({
    ...r,
    semesters: csv(r.semesters),
    areas: csv(r.areas),
    like_ids: links.filter((x) => x.profile_id === r.id && x.kind === "like").map((x) => x.complex_id),
    avoid_ids: links.filter((x) => x.profile_id === r.id && x.kind === "avoid").map((x) => x.complex_id),
    unmatched_like: like_complexes,
    unmatched_avoid: avoid_complexes,
  }));
}

export function profileForUser(userId: number): BuyerProfile | null {
  return hydrate(db.prepare("SELECT * FROM buyer_profiles WHERE user_id = ?").all(userId) as Row[])[0] ?? null;
}

export function allProfiles(): BuyerProfile[] {
  return hydrate(db.prepare("SELECT * FROM buyer_profiles ORDER BY active DESC, updated_at DESC").all() as Row[]);
}

function activeProfiles(): BuyerProfile[] {
  return hydrate(db.prepare("SELECT * FROM buyer_profiles WHERE active = 1").all() as Row[]);
}

/** Saves a profile and its favorite/avoid complexes. Returns the profile id. */
export function upsertProfile(input: ProfileInput, key: { userId?: number; id?: number; source?: "app" | "form" }): number {
  const values: Record<string, unknown> = {
    ...input,
    semesters: input.semesters.join(","),
    areas: input.areas.join(","),
    like_complexes: input.unmatched_like ?? "",
    avoid_complexes: input.unmatched_avoid ?? "",
  };
  const vals = COLUMNS.map((c) => values[c] ?? null);
  return db.transaction(() => {
    let id = key.id ?? (key.userId ? profileForUser(key.userId)?.id : undefined);
    if (id) {
      db.prepare(
        `UPDATE buyer_profiles SET ${COLUMNS.map((c) => `${c} = ?`).join(", ")}, updated_at = datetime('now') WHERE id = ?`
      ).run(...vals, id);
    } else {
      id = Number(
        db
          .prepare(
            `INSERT INTO buyer_profiles (user_id, source, ${COLUMNS.join(", ")}) VALUES (?, ?, ${COLUMNS.map(() => "?").join(", ")})`
          )
          .run(key.userId ?? null, key.source ?? "app", ...vals).lastInsertRowid
      );
    }
    db.prepare("DELETE FROM buyer_complexes WHERE profile_id = ?").run(id);
    const add = db.prepare("INSERT OR IGNORE INTO buyer_complexes (profile_id, complex_id, kind) VALUES (?, ?, ?)");
    // A complex can't be both; avoid wins.
    for (const c of input.avoid_ids) add.run(id, c, "avoid");
    for (const c of input.like_ids) add.run(id, c, "like");
    return id;
  })();
}

/** A fresh profile for a user, before they've answered anything. */
export function blankProfile(user: { name: string; email: string; phone: string | null }): ProfileInput {
  return {
    ...DEFAULT_PREFERENCES,
    name: user.name,
    email: user.email,
    phone: user.phone,
    social: null,
    contact_method: null,
    school: null,
    contracts_needed: 1,
    group_pref: "solo",
    takeover_ok: "yes",
    notes: null,
    alerts: "email",
    active: 1,
    complete: 0,
  };
}

// ---------- linking Google Form buyers to accounts ----------

const digits = (phone: string | null) => (phone ?? "").replace(/\D/g, "").slice(-10);

/**
 * If this user has no buyer profile yet, but a Google Form response came in
 * with their email or phone, attach that response to their account. Returns
 * true when a profile was linked.
 */
export function linkFormProfile(user: { id: number; email: string; phone: string | null }) {
  if (profileForUser(user.id)) return false;
  const candidates = db
    .prepare("SELECT id, email, phone FROM buyer_profiles WHERE source = 'form' AND user_id IS NULL")
    .all() as { id: number; email: string | null; phone: string | null }[];
  const phone = digits(user.phone);
  const hit =
    candidates.find((c) => c.email && c.email.toLowerCase() === user.email.toLowerCase()) ??
    (phone.length === 10 ? candidates.find((c) => digits(c.phone) === phone) : undefined);
  if (!hit) return false;
  db.prepare("UPDATE buyer_profiles SET user_id = ? WHERE id = ?").run(user.id, hit.id);
  return true;
}

/** Links a form profile to an existing account with the same email or phone. */
function linkToAccount(profileId: number, email: string | null, phone: string | null) {
  const users = db
    .prepare("SELECT id, email, phone FROM users WHERE id NOT IN (SELECT user_id FROM buyer_profiles WHERE user_id IS NOT NULL)")
    .all() as { id: number; email: string; phone: string | null }[];
  const p = digits(phone);
  const hit =
    (email ? users.find((u) => u.email.toLowerCase() === email.toLowerCase()) : undefined) ??
    (p.length === 10 ? users.find((u) => digits(u.phone) === p) : undefined);
  if (hit) db.prepare("UPDATE buyer_profiles SET user_id = ? WHERE id = ? AND user_id IS NULL").run(hit.id, profileId);
}

// ---------- Google Form import ----------

export type ImportedBuyer = Omit<ProfileInput, "like_ids" | "avoid_ids" | "unmatched_like" | "unmatched_avoid"> & {
  like_names: string;
  avoid_names: string;
};

/** Adds or updates form buyers, matched by email, phone, or (with neither) name. */
export function importFormBuyers(buyers: ImportedBuyer[]) {
  let added = 0;
  let updated = 0;
  const existing = db
    .prepare("SELECT id, name, email, phone FROM buyer_profiles WHERE source = 'form'")
    .all() as { id: number; name: string; email: string | null; phone: string | null }[];
  db.transaction(() => {
    for (const { like_names, avoid_names, ...b } of buyers) {
      const like = resolveComplexNames(db, like_names);
      const avoid = resolveComplexNames(db, avoid_names);
      const input: ProfileInput = {
        ...b,
        like_ids: like.ids,
        avoid_ids: avoid.ids,
        unmatched_like: like.unmatched,
        unmatched_avoid: avoid.unmatched,
      };
      const match = existing.find(
        (e) =>
          (b.email && e.email?.toLowerCase() === b.email.toLowerCase()) ||
          (b.phone && digits(e.phone) && digits(e.phone) === digits(b.phone)) ||
          (!b.email && !b.phone && !e.email && !e.phone && e.name === b.name)
      );
      const id = upsertProfile(input, match ? { id: match.id } : { source: "form" });
      linkToAccount(id, b.email, b.phone);
      if (match) updated++;
      else added++;
    }
  })();
  return { added, updated };
}

export function setProfileActive(id: number, active: boolean) {
  db.prepare("UPDATE buyer_profiles SET active = ?, updated_at = datetime('now') WHERE id = ?").run(active ? 1 : 0, id);
}

export function deleteSampleBuyers() {
  db.prepare("DELETE FROM buyer_profiles WHERE email LIKE '%@sample.provo-contracts.local'").run();
}

// ---------- matching listings to buyers ----------

/**
 * Run a newly posted listing against every active buyer profile. Strong
 * matches are recorded and the buyer gets an alert (stubbed until email or
 * text is set up). Returns how many buyers matched at all and how many were
 * alerted.
 */
export function matchNewListing(listingId: number) {
  const l = getListing(listingId);
  if (!l || l.status !== "active") return { matched: 0, alerted: 0 };
  const insert = db.prepare("INSERT OR IGNORE INTO matches (profile_id, listing_id, score, reasons) VALUES (?, ?, ?, ?)");
  let matched = 0;
  let alerted = 0;
  for (const p of activeProfiles()) {
    if (p.user_id === l.seller_id) continue;
    const m = scoreListing(p, l);
    if (!m) continue;
    matched++;
    if (m.score < ALERT_MIN_SCORE) continue;
    const res = insert.run(p.id, l.id, m.score, JSON.stringify(m.reasons));
    if (res.changes && p.alerts !== "off") {
      sendMatchAlert(p, l, m);
      alerted++;
    }
  }
  return { matched, alerted };
}

/** Active buyers whose dealbreakers this listing passes, best first. */
export function buyersForListing(listingId: number) {
  const l = getListing(listingId);
  if (!l) return [];
  return activeProfiles()
    .filter((p) => p.user_id !== l.seller_id)
    .map((p) => ({ profile: p, match: scoreListing(p, l) }))
    .filter((x): x is { profile: BuyerProfile; match: NonNullable<typeof x.match> } => !!x.match)
    .sort((a, z) => z.match.score - a.match.score);
}

/** Best few listings for each profile (admin buyer list). */
export function topMatchesByProfile(profiles: BuyerProfile[], limit = 3) {
  const listings = activeListings();
  return new Map(
    profiles.map((p) => {
      const ranked = listings
        .filter((l) => p.user_id !== l.seller_id)
        .map((l) => ({ l, m: scoreListing(p, l) }))
        .filter((x): x is { l: typeof x.l; m: NonNullable<typeof x.m> } => !!x.m)
        .sort((a, z) => z.m.score - a.m.score);
      return [p.id, { count: ranked.length, top: ranked.slice(0, limit) }] as const;
    })
  );
}

/** Strong matches recorded for this buyer that they haven't opened yet. */
export function newMatchesForUser(userId: number) {
  return db
    .prepare(
      `SELECT m.listing_id, m.score, m.reasons FROM matches m
       JOIN buyer_profiles p ON p.id = m.profile_id
       JOIN listings l ON l.id = m.listing_id
       WHERE p.user_id = ? AND m.seen = 0 AND l.status = 'active'
       ORDER BY m.created_at DESC`
    )
    .all(userId) as { listing_id: number; score: number; reasons: string }[];
}

export function markMatchSeen(userId: number, listingId: number) {
  db.prepare(
    `UPDATE matches SET seen = 1 WHERE listing_id = ?
     AND profile_id = (SELECT id FROM buyer_profiles WHERE user_id = ?)`
  ).run(listingId, userId);
}

export function alertOutbox(limit = 25) {
  return db
    .prepare(
      `SELECT n.*, p.name FROM notifications n JOIN buyer_profiles p ON p.id = n.profile_id
       ORDER BY n.id DESC LIMIT ?`
    )
    .all(limit) as { id: number; channel: string; to_address: string; body: string; status: string; created_at: string; name: string }[];
}
