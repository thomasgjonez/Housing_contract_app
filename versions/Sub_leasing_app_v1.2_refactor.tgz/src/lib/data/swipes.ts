import "server-only";
import { db } from "../db";

export function recordSwipe(userId: number, listingId: number, direction: "like" | "skip") {
  db.prepare(
    `INSERT INTO swipes (user_id, listing_id, direction) VALUES (?, ?, ?)
     ON CONFLICT(user_id, listing_id) DO UPDATE SET direction = excluded.direction, created_at = datetime('now')`
  ).run(userId, listingId, direction);
}

export function removeSwipe(userId: number, listingId: number) {
  db.prepare("DELETE FROM swipes WHERE user_id = ? AND listing_id = ?").run(userId, listingId);
}

export function clearSkips(userId: number) {
  db.prepare("DELETE FROM swipes WHERE user_id = ? AND direction = 'skip'").run(userId);
}

export function likedIds(userId: number) {
  const rows = db.prepare("SELECT listing_id AS id FROM swipes WHERE user_id = ? AND direction = 'like'").all(userId) as { id: number }[];
  return rows.map((r) => r.id);
}
