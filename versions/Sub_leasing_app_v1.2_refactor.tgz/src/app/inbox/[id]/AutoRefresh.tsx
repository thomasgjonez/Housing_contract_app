"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";

// Re-fetches the page every few seconds so new messages show up.
export function AutoRefresh({ seconds }: { seconds: number }) {
  const router = useRouter();
  useEffect(() => {
    const t = setInterval(() => router.refresh(), seconds * 1000);
    return () => clearInterval(t);
  }, [router, seconds]);
  return null;
}
