// Buyer filters. They live in the URL so the matcher, the map and a shared
// link all read the same thing.

export type Filters = {
  gender: "men" | "women" | "any";
  room: "private" | "shared" | "any";
  term: "fall-winter" | "spring-summer" | "full-year" | "any";
  maxRent: number | null;
  moveIn: string | null; // YYYY-MM
  maxWalk: number | null; // minutes
  parking: boolean;
  approvedOnly: boolean;
};

export const DEFAULT_FILTERS: Filters = {
  gender: "any",
  room: "any",
  term: "any",
  maxRent: null,
  moveIn: null,
  maxWalk: null,
  parking: false,
  approvedOnly: false,
};

type Params = Record<string, string | string[] | undefined> | URLSearchParams;

function get(p: Params, key: string): string | undefined {
  if (p instanceof URLSearchParams) return p.get(key) ?? undefined;
  const v = p[key];
  return Array.isArray(v) ? v[0] : v;
}

function num(v: string | undefined) {
  const n = Number(v);
  return v && Number.isFinite(n) && n > 0 ? Math.round(n) : null;
}

function oneOf<T extends string>(v: string | undefined, options: readonly T[], fallback: T): T {
  return options.includes(v as T) ? (v as T) : fallback;
}

export function parseFilters(p: Params): Filters {
  const moveIn = get(p, "moveIn");
  return {
    gender: oneOf(get(p, "gender"), ["men", "women", "any"] as const, "any"),
    room: oneOf(get(p, "room"), ["private", "shared", "any"] as const, "any"),
    term: oneOf(get(p, "term"), ["fall-winter", "spring-summer", "full-year", "any"] as const, "any"),
    maxRent: num(get(p, "maxRent")),
    moveIn: moveIn && /^\d{4}-\d{2}$/.test(moveIn) ? moveIn : null,
    maxWalk: num(get(p, "maxWalk")),
    parking: get(p, "parking") === "1",
    approvedOnly: get(p, "approvedOnly") === "1",
  };
}

export function filtersToQuery(f: Filters): string {
  const q = new URLSearchParams();
  if (f.gender !== "any") q.set("gender", f.gender);
  if (f.room !== "any") q.set("room", f.room);
  if (f.term !== "any") q.set("term", f.term);
  if (f.maxRent) q.set("maxRent", String(f.maxRent));
  if (f.moveIn) q.set("moveIn", f.moveIn);
  if (f.maxWalk) q.set("maxWalk", String(f.maxWalk));
  if (f.parking) q.set("parking", "1");
  if (f.approvedOnly) q.set("approvedOnly", "1");
  return q.toString();
}

export const TERM_LABEL: Record<string, string> = {
  "fall-winter": "Fall-Winter",
  "spring-summer": "Spring-Summer",
  "full-year": "Full year",
  other: "Other",
};

export const GENDER_LABEL: Record<string, string> = {
  men: "Men's",
  women: "Women's",
  coed: "Coed",
};

export function filterChips(f: Filters): string[] {
  const chips: string[] = [];
  if (f.gender !== "any") chips.push(`${GENDER_LABEL[f.gender]} housing`);
  if (f.room !== "any") chips.push(f.room === "private" ? "Private room" : "Shared room");
  if (f.maxRent) chips.push(`Up to $${f.maxRent}/mo`);
  if (f.moveIn) chips.push(`Move in by ${monthLabel(f.moveIn)}`);
  if (f.term !== "any") chips.push(TERM_LABEL[f.term]);
  if (f.maxWalk) chips.push(`≤ ${f.maxWalk} min walk`);
  if (f.parking) chips.push("Parking");
  if (f.approvedOnly) chips.push("BYU-approved");
  return chips;
}

export function monthLabel(ym: string) {
  const [y, m] = ym.split("-").map(Number);
  const names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${names[m - 1]} ${y}`;
}

export function dateLabel(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return `${monthLabel(`${y}-${String(m).padStart(2, "0")}`).split(" ")[0]} ${d}, ${y}`;
}
