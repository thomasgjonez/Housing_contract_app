import { GENDER_LABEL, dateLabel } from "./filters";
import type { BuyerProfile } from "./matching";

export function profileChips(p: BuyerProfile): string[] {
  const chips: string[] = [];
  if (p.gender !== "any") chips.push(`${GENDER_LABEL[p.gender]} housing`);
  if (p.room !== "any") chips.push(p.room === "private" ? "Private room" : "Shared room");
  if (p.max_rent) chips.push(`Up to $${p.max_rent}/mo`);
  if (p.move_in) chips.push(`Move in ${dateLabel(p.move_in)}${p.flex_days ? ` ±${p.flex_days}d` : ""}`);
  if (p.needs_approved === "yes") chips.push("BYU-approved");
  if (p.distance === "walk") chips.push("Walking distance");
  if (p.washer === "in-unit") chips.push("W/D in unit");
  return chips;
}
