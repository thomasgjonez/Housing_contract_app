import "server-only";
import { db } from "./db";
import type { Filters } from "./filters";
import { profileFromFilters, rank, type BuyerProfile, type MatchResult } from "./matching";

// Roughly the middle of BYU campus.
export const CAMPUS = { lat: 40.2518, lng: -111.6493 };

export type Listing = {
  id: number;
  seller_id: number;
  complex_id: number;
  complex: string;
  lat: number;
  lng: number;
  byu_approved: number;
  unit: string | null;
  housing_gender: "men" | "women" | "coed";
  room_type: "private" | "shared";
  rent_monthly: number;
  deposit: number | null;
  utilities_included: number;
  start_date: string;
  end_date: string;
  contract_term: string;
  incentive: string | null;
  parking: number;
  description: string | null;
  contact_note: string | null;
  status: string;
  source: string;
  created_at: string;
  photo: string | null;
  furnished: number;
  washer_dryer: string;
  private_bath: number;
  pets_allowed: number;
  city: string;
  walk_minutes: number;
};

export type ScoredListing = Listing & MatchResult;

const BASE = `
  SELECT l.*, c.name AS complex, c.lat, c.lng, c.byu_approved, c.city,
    (SELECT file FROM photos p WHERE p.listing_id = l.id ORDER BY position LIMIT 1) AS photo
  FROM listings l JOIN complexes c ON c.id = l.complex_id`;

// Straight-line distance to campus, padded for streets, at a 80 m/min walk.
export function walkMinutes(lat: number, lng: number) {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat - CAMPUS.lat);
  const dLng = toRad(lng - CAMPUS.lng);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(CAMPUS.lat)) * Math.cos(toRad(lat)) * Math.sin(dLng / 2) ** 2;
  const meters = 2 * R * Math.asin(Math.sqrt(a));
  return Math.max(1, Math.round((meters * 1.3) / 80));
}

function withWalk(rows: Omit<Listing, "walk_minutes">[]): Listing[] {
  return rows.map((r) => ({ ...r, walk_minutes: walkMinutes(r.lat, r.lng) }));
}

export function getListing(id: number): Listing | null {
  const row = db.prepare(`${BASE} WHERE l.id = ?`).get(id) as Omit<Listing, "walk_minutes"> | undefined;
  return row ? withWalk([row])[0] : null;
}

export function getPhotos(listingId: number): string[] {
  return (
    db.prepare("SELECT file FROM photos WHERE listing_id = ? ORDER BY position").all(listingId) as { file: string }[]
  ).map((p) => p.file);
}

export function listingsBySeller(sellerId: number): Listing[] {
  return withWalk(
    db.prepare(`${BASE} WHERE l.seller_id = ? ORDER BY l.created_at DESC`).all(sellerId) as Omit<Listing, "walk_minutes">[]
  );
}

export function likedListings(userId: number): Listing[] {
  return withWalk(
    db
      .prepare(
        `${BASE} JOIN swipes s ON s.listing_id = l.id
         WHERE s.user_id = ? AND s.direction = 'like' AND l.status IN ('active','pending')
         ORDER BY s.created_at DESC`
      )
      .all(userId) as Omit<Listing, "walk_minutes">[]
  );
}

export function recentListings(limit = 6): Listing[] {
  return withWalk(
    db.prepare(`${BASE} WHERE l.status = 'active' ORDER BY l.bumped_at DESC LIMIT ?`).all(limit) as Omit<
      Listing,
      "walk_minutes"
    >[]
  );
}

export function activeListings(opts: { excludeSwipedBy?: number; excludeSeller?: number } = {}): Listing[] {
  const where = ["l.status = 'active'"];
  const args: number[] = [];
  if (opts.excludeSwipedBy) {
    where.push("l.id NOT IN (SELECT listing_id FROM swipes WHERE user_id = ?)");
    args.push(opts.excludeSwipedBy);
  }
  if (opts.excludeSeller) {
    where.push("l.seller_id != ?");
    args.push(opts.excludeSeller);
  }
  return withWalk(
    db.prepare(`${BASE} WHERE ${where.join(" AND ")} ORDER BY l.bumped_at DESC`).all(...args) as Omit<Listing, "walk_minutes">[]
  );
}

export function likedComplexIds(userId: number) {
  const rows = db
    .prepare(
      `SELECT DISTINCT l.complex_id AS id FROM swipes s JOIN listings l ON l.id = s.listing_id
       WHERE s.user_id = ? AND s.direction = 'like'`
    )
    .all(userId) as { id: number }[];
  return new Set(rows.map((r) => r.id));
}

export function likedIds(userId: number) {
  const rows = db.prepare("SELECT listing_id AS id FROM swipes WHERE user_id = ? AND direction = 'like'").all(userId) as { id: number }[];
  return rows.map((r) => r.id);
}

// Ranked matches for a buyer profile (the full matcher).
export function matchListings(
  p: BuyerProfile,
  opts: { userId?: number; excludeSwiped?: boolean } = {}
): ScoredListing[] {
  const listings = activeListings({
    excludeSwipedBy: opts.excludeSwiped ? opts.userId : undefined,
    excludeSeller: opts.userId,
  });
  return rank(p, listings, { likedComplexIds: opts.userId ? likedComplexIds(opts.userId) : undefined });
}

// Quick filters from the URL go through the same matcher.
export function searchListings(f: Filters, opts: { excludeSwipedBy?: number } = {}): ScoredListing[] {
  return rank(profileFromFilters(f), activeListings(opts), {
    likedComplexIds: opts.excludeSwipedBy ? likedComplexIds(opts.excludeSwipedBy) : undefined,
  });
}
