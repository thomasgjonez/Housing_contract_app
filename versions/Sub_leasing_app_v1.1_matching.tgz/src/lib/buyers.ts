import "server-only";
import { db } from "./db";
import { activeListings, getListing } from "./listings";
import { ALERT_MIN_SCORE, scoreListing, type BuyerProfile } from "./matching";
import { sendMatchAlert } from "./notify";

export type ProfileRow = BuyerProfile & {
  id: number;
  user_id: number | null;
  source: "app" | "form";
  name: string;
  email: string | null;
  phone: string | null;
  social: string | null;
  contact_method: string | null;
  school: string | null;
  contracts_needed: number;
  group_pref: string;
  takeover_ok: string;
  notes: string | null;
  alerts: "email" | "text" | "both" | "off";
  active: number;
  created_at: string;
  updated_at: string;
};

export const PROFILE_FIELDS = [
  "name", "email", "phone", "social", "contact_method", "school", "contracts_needed", "group_pref",
  "gender", "needs_approved", "move_in", "flex_days", "semesters", "term", "max_rent", "utilities",
  "room", "bath", "furnished", "washer", "areas", "distance", "like_complexes", "avoid_complexes",
  "parking", "pets", "takeover_ok", "notes", "alerts", "active",
] as const;

export type ProfileInput = Pick<ProfileRow, (typeof PROFILE_FIELDS)[number]>;

export function profileForUser(userId: number): ProfileRow | null {
  return (db.prepare("SELECT * FROM buyer_profiles WHERE user_id = ?").get(userId) as ProfileRow | undefined) ?? null;
}

export function getProfile(id: number): ProfileRow | null {
  return (db.prepare("SELECT * FROM buyer_profiles WHERE id = ?").get(id) as ProfileRow | undefined) ?? null;
}

export function allProfiles(): ProfileRow[] {
  return db.prepare("SELECT * FROM buyer_profiles ORDER BY active DESC, updated_at DESC").all() as ProfileRow[];
}

export function upsertProfile(input: ProfileInput, key: { userId?: number; id?: number; source?: "app" | "form" }) {
  const cols = PROFILE_FIELDS.join(", ");
  const vals = PROFILE_FIELDS.map((f) => input[f] ?? null);
  if (key.id) {
    db.prepare(
      `UPDATE buyer_profiles SET ${PROFILE_FIELDS.map((f) => `${f} = ?`).join(", ")}, updated_at = datetime('now') WHERE id = ?`
    ).run(...vals, key.id);
    return key.id;
  }
  if (key.userId) {
    const existing = profileForUser(key.userId);
    if (existing) return upsertProfile(input, { id: existing.id });
  }
  const res = db
    .prepare(
      `INSERT INTO buyer_profiles (user_id, source, ${cols}) VALUES (?, ?, ${PROFILE_FIELDS.map(() => "?").join(", ")})`
    )
    .run(key.userId ?? null, key.source ?? "app", ...vals);
  return Number(res.lastInsertRowid);
}

/**
 * Run a newly posted listing against every active buyer profile. Strong
 * matches are recorded and the buyer gets an alert (stubbed until email or
 * text is set up). Returns how many buyers matched at all and how many were
 * alerted.
 */
export function matchNewListing(listingId: number) {
  const l = getListing(listingId);
  if (!l || l.status !== "active") return { matched: 0, alerted: 0 };
  const profiles = db.prepare("SELECT * FROM buyer_profiles WHERE active = 1").all() as ProfileRow[];
  const insert = db.prepare(
    "INSERT OR IGNORE INTO matches (profile_id, listing_id, score, reasons) VALUES (?, ?, ?, ?)"
  );
  let matched = 0;
  let alerted = 0;
  for (const p of profiles) {
    if (p.user_id === l.seller_id) continue;
    const m = scoreListing(p, l);
    if (!m) continue;
    matched++;
    if (m.score < ALERT_MIN_SCORE) continue;
    const res = insert.run(p.id, l.id, m.score, JSON.stringify(m.reasons));
    if (res.changes && p.alerts !== "off") {
      sendMatchAlert(p, l, m);
      alerted++;
    }
  }
  return { matched, alerted };
}

/** Active buyers whose dealbreakers this listing passes, best first. */
export function buyersForListing(listingId: number) {
  const l = getListing(listingId);
  if (!l) return [];
  const profiles = db.prepare("SELECT * FROM buyer_profiles WHERE active = 1").all() as ProfileRow[];
  return profiles
    .filter((p) => p.user_id !== l.seller_id)
    .map((p) => ({ profile: p, match: scoreListing(p, l) }))
    .filter((x): x is { profile: ProfileRow; match: NonNullable<typeof x.match> } => !!x.match)
    .sort((a, z) => z.match.score - a.match.score);
}

/** Best few listings for each profile (admin buyer list). */
export function topMatchesByProfile(limit = 3) {
  const listings = activeListings();
  return new Map(
    allProfiles().map((p) => {
      const ranked = listings
        .map((l) => ({ l, m: scoreListing(p, l) }))
        .filter((x) => x.m && p.user_id !== x.l.seller_id)
        .sort((a, z) => z.m!.score - a.m!.score);
      return [p.id, { count: ranked.length, top: ranked.slice(0, limit) }] as const;
    })
  );
}

/** Strong matches recorded for this buyer that they haven't opened yet. */
export function newMatchesForUser(userId: number) {
  return db
    .prepare(
      `SELECT m.listing_id, m.score, m.reasons FROM matches m
       JOIN buyer_profiles p ON p.id = m.profile_id
       JOIN listings l ON l.id = m.listing_id
       WHERE p.user_id = ? AND m.seen = 0 AND l.status = 'active'
       ORDER BY m.created_at DESC`
    )
    .all(userId) as { listing_id: number; score: number; reasons: string }[];
}

export function markMatchSeen(userId: number, listingId: number) {
  db.prepare(
    `UPDATE matches SET seen = 1 WHERE listing_id = ?
     AND profile_id = (SELECT id FROM buyer_profiles WHERE user_id = ?)`
  ).run(listingId, userId);
}
