import Link from "next/link";
import { currentUser } from "@/lib/auth";
import { parseFilters, filtersToQuery } from "@/lib/filters";
import { likedIds, matchListings, searchListings } from "@/lib/listings";
import { newMatchesForUser, profileForUser } from "@/lib/buyers";
import { profileChips } from "@/lib/profileChips";
import { FilterBar } from "@/components/FilterBar";
import { SwipeDeck } from "./SwipeDeck";
import { MatchGrid } from "./MatchGrid";

const FILTER_KEYS = ["gender", "room", "term", "maxRent", "moveIn", "maxWalk", "parking", "approvedOnly"];

export default async function Match({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const sp = await searchParams;
  const view = sp.v === "grid" ? "grid" : "swipe";
  const user = await currentUser();
  const profile = user ? profileForUser(user.id) : null;
  const filters = parseFilters(sp);
  // A saved profile drives the matcher unless quick filters are in the URL.
  const useProfile = !!profile?.active && !FILTER_KEYS.some((k) => sp[k]);

  const all = useProfile
    ? matchListings(profile!, { userId: user!.id })
    : searchListings(filters).filter((l) => l.seller_id !== user?.id);
  const deck = !user
    ? all
    : useProfile
      ? matchListings(profile!, { userId: user.id, excludeSwiped: true })
      : searchListings(filters, { excludeSwipedBy: user.id }).filter((l) => l.seller_id !== user.id);
  const liked = user ? likedIds(user.id) : [];
  const fresh = user ? newMatchesForUser(user.id).map((m) => m.listing_id) : [];

  // Swipe and Grid share the same filters (and the same likes).
  const q = useProfile ? "" : filtersToQuery(filters);
  const link = (v: "swipe" | "grid") => {
    const params = new URLSearchParams(q);
    if (v === "grid") params.set("v", "grid");
    const s = params.toString();
    return s ? `/match?${s}` : "/match";
  };

  return (
    <div>
      {sp.saved && (
        <div className="mb-4 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-900">
          Profile saved. These are ranked for you, and we&apos;ll alert you when a strong new match is posted.
        </div>
      )}

      <div className="mb-4 flex items-center gap-3">
        <div className="inline-flex rounded-xl bg-white p-1 ring-1 ring-slate-200">
          <Link href={link("swipe")} className={`rounded-lg px-4 py-1.5 text-sm font-semibold ${view === "swipe" ? "bg-brand-600 text-white" : "text-slate-600"}`}>♥ Swipe</Link>
          <Link href={link("grid")} className={`rounded-lg px-4 py-1.5 text-sm font-semibold ${view === "grid" ? "bg-brand-600 text-white" : "text-slate-600"}`}>▦ Grid</Link>
        </div>
        {fresh.length > 0 && (
          <span className="rounded-full bg-rose-100 px-2.5 py-1 text-xs font-bold text-rose-700">
            {fresh.length} new {fresh.length === 1 ? "match" : "matches"}
          </span>
        )}
      </div>

      {useProfile ? (
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <span className="text-sm font-semibold">{all.length} {all.length === 1 ? "match" : "matches"} for your profile</span>
          {profileChips(profile!).map((c) => <span key={c} className="chip">{c}</span>)}
          <div className="ml-auto flex gap-2">
            <Link href="/profile" className="btn-ghost !py-1.5">Edit profile</Link>
          </div>
        </div>
      ) : (
        <>
          <FilterBar filters={filters} view="match" count={all.length} />
          <div className="mb-4 rounded-xl bg-brand-50 p-3 text-sm text-brand-800">
            {profile?.active ? (
              <>Showing quick filters. <Link href={view === "grid" ? "/match?v=grid" : "/match"} className="font-semibold underline">Back to your profile matches</Link></>
            ) : (
              <>Picky about what you need? <Link href="/profile" className="font-semibold underline">Build a buyer profile</Link> to rank every listing for you and get alerts when a match is posted.</>
            )}
          </div>
        </>
      )}

      {view === "grid" ? (
        <MatchGrid cards={all} liked={liked} fresh={fresh} loggedIn={!!user} />
      ) : (
        <SwipeDeck key={deck.map((c) => c.id).join(",")} cards={deck} loggedIn={!!user} totalMatches={all.length} fresh={fresh} />
      )}
    </div>
  );
}
