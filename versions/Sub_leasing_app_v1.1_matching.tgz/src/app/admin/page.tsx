import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { deleteSamples, updateComplex } from "@/lib/actions";
import { ComplexLocations } from "./ComplexLocations";

type Complex = { id: number; name: string; city: string; lat: number; lng: number; byu_approved: number; management_company: string | null; pms: string | null; location_verified: number };

export default async function Admin() {
  const user = await requireUser("/admin");
  if (!user.is_admin) redirect("/");
  const complexes = db.prepare("SELECT * FROM complexes ORDER BY name").all() as Complex[];
  const counts = db.prepare("SELECT source, status, count(*) AS n FROM listings GROUP BY source, status").all() as { source: string; status: string; n: number }[];
  const users = db.prepare("SELECT count(*) AS n FROM users WHERE password_hash NOT LIKE '!%'").get() as { n: number };
  const samples = counts.filter((c) => c.source === "sample").reduce((a, c) => a + c.n, 0);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold">Admin</h1>
        <a href="/admin/buyers" className="btn-primary !py-1.5">Buyers and matching →</a>
      </div>

      <section className="grid gap-4 sm:grid-cols-3">
        <div className="card p-5"><div className="text-sm text-slate-500">Accounts</div><div className="text-3xl font-extrabold">{users.n}</div></div>
        <div className="card p-5">
          <div className="text-sm text-slate-500">Listings by source and status</div>
          <ul className="mt-1 text-sm">{counts.map((c) => <li key={c.source + c.status}>{c.source} · {c.status}: <b>{c.n}</b></li>)}</ul>
        </div>
        <div className="card space-y-2 p-5">
          <div className="text-sm text-slate-500">Sample listings</div>
          <div className="text-3xl font-extrabold">{samples}</div>
          {samples > 0 && (
            <form action={deleteSamples}><button className="btn-ghost !py-1.5 text-rose-700">Delete all samples</button></form>
          )}
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="text-xl font-bold">Complex locations</h2>
        <p className="text-sm text-slate-600">Starting pins are approximate. Pick a complex, then click its real spot on the map. Verified pins turn green in the list.</p>
        <ComplexLocations complexes={complexes} />
      </section>

      <section className="space-y-3">
        <h2 className="text-xl font-bold">Complex details</h2>
        <p className="text-sm text-slate-600">The property-management software field is for the later Entrata integration.</p>
        <div className="card divide-y divide-slate-100">
          {complexes.map((c) => (
            <form key={c.id} action={updateComplex} className="grid items-center gap-2 p-3 sm:grid-cols-[1.5fr_auto_1.2fr_1fr_auto]">
              <input type="hidden" name="id" value={c.id} />
              <div className="flex gap-2">
                <input name="name" defaultValue={c.name} className="input" />
                <select name="city" defaultValue={c.city} className="input !w-32">
                  {["Provo", "Orem", "Vineyard", "Springville", "Lehi / American Fork"].map((x) => <option key={x}>{x}</option>)}
                </select>
              </div>
              <label className="flex items-center gap-2 text-sm whitespace-nowrap"><input type="checkbox" name="byuApproved" defaultChecked={!!c.byu_approved} /> BYU-approved</label>
              <input name="managementCompany" defaultValue={c.management_company ?? ""} placeholder="Management company" className="input" />
              <input name="pms" defaultValue={c.pms ?? ""} placeholder="Software (e.g. Entrata)" className="input" />
              <button className="btn-ghost !py-2">Save</button>
            </form>
          ))}
        </div>
      </section>
    </div>
  );
}
