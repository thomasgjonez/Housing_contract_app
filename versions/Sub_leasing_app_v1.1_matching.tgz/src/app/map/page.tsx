import { parseFilters } from "@/lib/filters";
import { CAMPUS, searchListings } from "@/lib/listings";
import { FilterBar } from "@/components/FilterBar";
import { MapView } from "./MapView";

export default async function MapPage({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const filters = parseFilters(await searchParams);
  const listings = searchListings(filters);
  return (
    <div>
      <FilterBar filters={filters} view="map" count={listings.length} />
      <MapView listings={listings} campus={CAMPUS} />
    </div>
  );
}
