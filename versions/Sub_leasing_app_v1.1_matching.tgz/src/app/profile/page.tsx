import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { profileForUser } from "@/lib/buyers";
import { ProfileForm } from "./ProfileForm";

export default async function ProfilePage() {
  const user = await requireUser("/profile");
  const profile = profileForUser(user.id);
  const complexes = (db.prepare("SELECT name FROM complexes ORDER BY name").all() as { name: string }[]).map((c) => c.name);
  return (
    <ProfileForm
      profile={profile}
      user={{ name: user.name, email: user.email, phone: user.phone ?? "" }}
      complexes={complexes}
    />
  );
}
