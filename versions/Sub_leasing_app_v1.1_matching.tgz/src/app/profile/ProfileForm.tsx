"use client";

import { useActionState } from "react";
import { saveProfile } from "@/lib/actions";
import type { ProfileRow } from "@/lib/buyers";
import { mentionsComplex } from "@/lib/matching";

function Choice({ name, value, label, current }: { name: string; value: string; label: string; current: string }) {
  return (
    <label className="cursor-pointer">
      <input type="radio" name={name} value={value} defaultChecked={current === value} className="peer sr-only" />
      <span className="block h-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-center text-sm font-medium peer-checked:border-brand-600 peer-checked:bg-brand-50 peer-checked:text-brand-700">
        {label}
      </span>
    </label>
  );
}

function Row({ label, hint, children, cols = 3 }: { label: string; hint?: string; children: React.ReactNode; cols?: number }) {
  return (
    <div>
      <span className="label">{label}</span>
      {hint && <span className="-mt-1 mb-1.5 block text-xs text-slate-500">{hint}</span>}
      <div className={`grid gap-2 ${cols === 2 ? "grid-cols-2" : cols === 4 ? "grid-cols-2 sm:grid-cols-4" : "grid-cols-3"}`}>{children}</div>
    </div>
  );
}

function Check({ name, value, label, checked }: { name: string; value: string; label: string; checked: boolean }) {
  return (
    <label className="cursor-pointer">
      <input type="checkbox" name={name} value={value} defaultChecked={checked} className="peer sr-only" />
      <span className="block rounded-full border border-slate-300 bg-white px-3 py-1.5 text-sm peer-checked:border-brand-600 peer-checked:bg-brand-50 peer-checked:text-brand-700">
        {label}
      </span>
    </label>
  );
}

const AREAS = ["Provo", "Orem", "Vineyard", "Springville", "Lehi / American Fork"];

export function ProfileForm({
  profile: p,
  user,
  complexes,
}: {
  profile: ProfileRow | null;
  user: { name: string; email: string; phone: string };
  complexes: string[];
}) {
  const [state, action, pending] = useActionState(saveProfile, undefined);
  const sem = (p?.semesters ?? "").split(",");
  const areas = p ? p.areas.split(",") : ["Provo"];
  // Favorites typed elsewhere (e.g. imported) that aren't in the list stay in the text box.
  const likedOther = (p?.like_complexes ?? "").split(",").map((s) => s.trim()).filter((s) => s && !complexes.some((c) => mentionsComplex(s, c))).join(", ");
  const avoidOther = (p?.avoid_complexes ?? "").split(",").map((s) => s.trim()).filter((s) => s && !complexes.some((c) => mentionsComplex(s, c))).join(", ");

  return (
    <form action={action} className="mx-auto max-w-xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">{p ? "Your buyer profile" : "Get matched"}</h1>
        <p className="text-slate-600">
          Fill this out once. Dealbreakers hide listings that won&apos;t work, and everything else ranks the rest. We&apos;ll alert you when a strong match is posted.
        </p>
      </div>

      <section className="card space-y-5 p-5">
        <h2 className="font-bold">Dealbreakers</h2>
        <Row label="Housing">
          <Choice name="gender" value="women" label="Women's" current={p?.gender ?? ""} />
          <Choice name="gender" value="men" label="Men's" current={p?.gender ?? ""} />
          <Choice name="gender" value="any" label="Co-ed is fine" current={p?.gender ?? "any"} />
        </Row>
        <Row label="BYU-approved housing">
          <Choice name="needs_approved" value="yes" label="Required" current={p?.needs_approved ?? ""} />
          <Choice name="needs_approved" value="no" label="Not needed" current={p?.needs_approved ?? ""} />
          <Choice name="needs_approved" value="unsure" label="Not sure" current={p?.needs_approved ?? "unsure"} />
        </Row>
        <Row label="Bedroom">
          <Choice name="room" value="private" label="Private" current={p?.room ?? ""} />
          <Choice name="room" value="shared" label="Shared" current={p?.room ?? ""} />
          <Choice name="room" value="any" label="Either" current={p?.room ?? "any"} />
        </Row>
        <div className="grid grid-cols-2 gap-3">
          <label>
            <span className="label">Max rent ($/month)</span>
            <input name="max_rent" type="number" min={0} defaultValue={p?.max_rent ?? ""} placeholder="e.g. 550" className="input" />
          </label>
          <label>
            <span className="label">Move-in date</span>
            <input name="move_in" type="date" required defaultValue={p?.move_in ?? ""} className="input" />
          </label>
        </div>
        <Row label="How flexible is the move-in date?" cols={4}>
          <Choice name="flex_days" value="0" label="Exact" current={String(p?.flex_days ?? 7)} />
          <Choice name="flex_days" value="7" label="± a week" current={String(p?.flex_days ?? 7)} />
          <Choice name="flex_days" value="21" label="2–3 weeks" current={String(p?.flex_days ?? 7)} />
          <Choice name="flex_days" value="60" label="Very" current={String(p?.flex_days ?? 7)} />
        </Row>
        <div>
          <span className="label">Areas you&apos;d live in</span>
          <div className="flex flex-wrap gap-2">
            {AREAS.map((a) => <Check key={a} name="areas" value={a} label={a} checked={areas.includes(a)} />)}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label>
            <span className="label">Parking</span>
            <select name="parking" defaultValue={p?.parking ?? "none"} className="input">
              <option value="none">Don&apos;t need it</option>
              <option value="need">Need a pass</option>
              <option value="covered">Need covered</option>
            </select>
          </label>
          <label>
            <span className="label">Pets</span>
            <select name="pets" defaultValue={p?.pets ?? "none"} className="input">
              <option value="none">No pets</option>
              <option value="pet">I have a pet</option>
              <option value="esa">Emotional support animal</option>
            </select>
          </label>
        </div>
        <div>
          <span className="label">Complexes to avoid</span>
          <div className="flex flex-wrap gap-2">
            {complexes.map((c) => <Check key={c} name="avoid_complexes" value={c} label={c} checked={!!p && mentionsComplex(p.avoid_complexes, c)} />)}
          </div>
          <input name="avoid_complexes" defaultValue={avoidOther} placeholder="Others, separated by commas" className="input mt-2" />
        </div>
      </section>

      <section className="card space-y-5 p-5">
        <h2 className="font-bold">Nice to have</h2>
        <p className="-mt-3 text-sm text-slate-600">These don&apos;t hide anything. They move the best fits to the top.</p>
        <div>
          <span className="label">Semesters you need</span>
          <div className="flex flex-wrap gap-2">
            {["Fall", "Winter", "Spring", "Summer"].map((s) => <Check key={s} name="semesters" value={s} label={s} checked={sem.includes(s)} />)}
          </div>
        </div>
        <label className="block">
          <span className="label">Contract length</span>
          <select name="term" defaultValue={p?.term ?? "any"} className="input">
            <option value="any">Flexible</option>
            <option value="one-semester">One semester</option>
            <option value="fall-winter">Fall + Winter</option>
            <option value="spring-summer">Spring + Summer</option>
            <option value="full-year">Full year</option>
          </select>
        </label>
        <Row label="Distance to campus" cols={4}>
          <Choice name="distance" value="walk" label="Walking" current={p?.distance ?? "any"} />
          <Choice name="distance" value="drive10" label="≤ 10 min drive" current={p?.distance ?? "any"} />
          <Choice name="distance" value="drive20" label="≤ 20 min drive" current={p?.distance ?? "any"} />
          <Choice name="distance" value="any" label="Doesn't matter" current={p?.distance ?? "any"} />
        </Row>
        <div>
          <span className="label">Complexes you like</span>
          <div className="flex flex-wrap gap-2">
            {complexes.map((c) => <Check key={c} name="like_complexes" value={c} label={c} checked={!!p && mentionsComplex(p.like_complexes, c)} />)}
          </div>
          <input name="like_complexes" defaultValue={likedOther} placeholder="Others, separated by commas" className="input mt-2" />
        </div>
        <Row label="Washer/dryer">
          <Choice name="washer" value="in-unit" label="In unit" current={p?.washer ?? "any"} />
          <Choice name="washer" value="on-site" label="On-site is fine" current={p?.washer ?? "any"} />
          <Choice name="washer" value="any" label="No preference" current={p?.washer ?? "any"} />
        </Row>
        <Row label="Furnished">
          <Choice name="furnished" value="must" label="Must be" current={p?.furnished ?? "any"} />
          <Choice name="furnished" value="prefer" label="Prefer" current={p?.furnished ?? "any"} />
          <Choice name="furnished" value="any" label="Either" current={p?.furnished ?? "any"} />
        </Row>
        <Row label="Utilities">
          <Choice name="utilities" value="must" label="Must be included" current={p?.utilities ?? "any"} />
          <Choice name="utilities" value="prefer" label="Prefer included" current={p?.utilities ?? "any"} />
          <Choice name="utilities" value="any" label="Don't mind" current={p?.utilities ?? "any"} />
        </Row>
        <Row label="Bathroom" cols={2}>
          <Choice name="bath" value="private" label="Want my own" current={p?.bath ?? "any"} />
          <Choice name="bath" value="any" label="Sharing is fine" current={p?.bath ?? "any"} />
        </Row>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="font-bold">About you</h2>
        <div className="grid grid-cols-2 gap-3">
          <label><span className="label">Name</span><input name="name" required defaultValue={p?.name ?? user.name} className="input" /></label>
          <label>
            <span className="label">School</span>
            <select name="school" defaultValue={p?.school ?? "BYU"} className="input">
              <option>BYU</option><option>UVU</option><option>Other</option>
            </select>
          </label>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <label>
            <span className="label">Contracts needed</span>
            <select name="contracts_needed" defaultValue={p?.contracts_needed ?? 1} className="input">
              {[1, 2, 3, 4, 5, 6].map((n) => <option key={n} value={n}>{n === 6 ? "6+" : n}</option>)}
            </select>
          </label>
          <label>
            <span className="label">With a group?</span>
            <select name="group_pref" defaultValue={p?.group_pref ?? "solo"} className="input">
              <option value="solo">Just me</option>
              <option value="same-unit">Yes, same unit</option>
              <option value="same-complex">Yes, same complex is fine</option>
            </select>
          </label>
        </div>
        <label className="block"><span className="label">Anything else?</span><textarea name="notes" rows={2} defaultValue={p?.notes ?? ""} className="input" placeholder="Roommate preferences, accessibility needs…" /></label>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="font-bold">Match alerts</h2>
        <Row label="Tell me about strong new matches by" cols={4}>
          <Choice name="alerts" value="email" label="Email" current={p?.alerts ?? "email"} />
          <Choice name="alerts" value="text" label="Text" current={p?.alerts ?? "email"} />
          <Choice name="alerts" value="both" label="Both" current={p?.alerts ?? "email"} />
          <Choice name="alerts" value="off" label="Don't" current={p?.alerts ?? "email"} />
        </Row>
        <div className="grid grid-cols-2 gap-3">
          <label><span className="label">Email</span><input name="email" type="email" defaultValue={p?.email ?? user.email} className="input" /></label>
          <label><span className="label">Phone</span><input name="phone" type="tel" defaultValue={p?.phone ?? user.phone} className="input" placeholder="For texts" /></label>
        </div>
        {p && (
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="paused" defaultChecked={!p.active} /> Pause my search (found a place)</label>
        )}
      </section>

      {state?.error && <div className="rounded-xl bg-rose-50 p-3 text-sm text-rose-800">{state.error}</div>}
      <button className="btn-primary w-full py-3" disabled={pending}>{pending ? "Saving…" : p ? "Save and see matches" : "Show my matches"}</button>
    </form>
  );
}
