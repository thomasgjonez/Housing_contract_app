import Link from "next/link";
import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { sendMessage } from "@/lib/actions";
import { AutoRefresh } from "./AutoRefresh";

export default async function Conversation({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser(`/inbox/${id}`);
  const conv = db
    .prepare(
      `SELECT c.*, cx.name AS complex, l.rent_monthly, l.status, b.name AS buyer_name, s.name AS seller_name
       FROM conversations c JOIN listings l ON l.id = c.listing_id JOIN complexes cx ON cx.id = l.complex_id
       JOIN users b ON b.id = c.buyer_id JOIN users s ON s.id = c.seller_id
       WHERE c.id = ? AND (c.buyer_id = ? OR c.seller_id = ?)`
    )
    .get(Number(id), user.id, user.id) as
    | { id: number; listing_id: number; buyer_id: number; complex: string; rent_monthly: number; status: string; buyer_name: string; seller_name: string }
    | undefined;
  if (!conv) notFound();

  db.prepare("UPDATE messages SET read_at = datetime('now') WHERE conversation_id = ? AND sender_id != ? AND read_at IS NULL").run(conv.id, user.id);
  const messages = db
    .prepare("SELECT id, sender_id, body, created_at FROM messages WHERE conversation_id = ? ORDER BY id")
    .all(conv.id) as { id: number; sender_id: number; body: string; created_at: string }[];
  const other = conv.buyer_id === user.id ? conv.seller_name : conv.buyer_name;

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-4">
      <AutoRefresh seconds={4} />
      <div className="card flex items-center justify-between p-4">
        <div>
          <div className="font-bold">{other}</div>
          <Link href={`/listings/${conv.listing_id}`} className="text-sm text-brand-600">
            {conv.complex} · ${conv.rent_monthly}/mo {conv.status !== "active" && `(${conv.status})`}
          </Link>
        </div>
        <Link href="/inbox" className="btn-ghost !py-1.5">All messages</Link>
      </div>

      <div className="space-y-2">
        {messages.length === 0 && <div className="text-center text-sm text-slate-500">Say hi to start the conversation.</div>}
        {messages.map((m) => {
          const mine = m.sender_id === user.id;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] whitespace-pre-line rounded-2xl px-4 py-2 text-sm ${mine ? "bg-brand-600 text-white" : "bg-white ring-1 ring-slate-200"}`}>
                {m.body}
                <div className={`mt-1 text-[10px] ${mine ? "text-white/70" : "text-slate-400"}`}>{m.created_at.slice(5, 16).replace("T", " ")} UTC</div>
              </div>
            </div>
          );
        })}
      </div>

      <form action={sendMessage} className="sticky bottom-20 flex gap-2 md:bottom-4">
        <input type="hidden" name="conversationId" value={conv.id} />
        <input name="body" required autoComplete="off" placeholder="Write a message…" className="input" />
        <button className="btn-primary">Send</button>
      </form>
    </div>
  );
}
