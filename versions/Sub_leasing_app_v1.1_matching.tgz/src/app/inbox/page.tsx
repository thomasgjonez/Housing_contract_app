import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";

type Row = {
  id: number;
  complex: string;
  rent_monthly: number;
  other_name: string;
  i_am_seller: number;
  last_body: string | null;
  last_at: string | null;
  unread: number;
};

export default async function Inbox() {
  const user = await requireUser("/inbox");
  const rows = db
    .prepare(
      `SELECT c.id, cx.name AS complex, l.rent_monthly,
         CASE WHEN c.seller_id = @me THEN b.name ELSE s.name END AS other_name,
         c.seller_id = @me AS i_am_seller,
         (SELECT body FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) AS last_body,
         (SELECT created_at FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) AS last_at,
         (SELECT count(*) FROM messages WHERE conversation_id = c.id AND sender_id != @me AND read_at IS NULL) AS unread
       FROM conversations c
       JOIN listings l ON l.id = c.listing_id
       JOIN complexes cx ON cx.id = l.complex_id
       JOIN users b ON b.id = c.buyer_id
       JOIN users s ON s.id = c.seller_id
       WHERE c.buyer_id = @me OR c.seller_id = @me
       ORDER BY coalesce(last_at, c.created_at) DESC`
    )
    .all({ me: user.id }) as Row[];

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="text-2xl font-extrabold">Inbox</h1>
      {rows.length === 0 && (
        <div className="card p-8 text-center text-slate-600">
          No messages yet. <Link href="/match" className="font-semibold text-brand-600">Find a contract</Link> or{" "}
          <Link href="/sell" className="font-semibold text-brand-600">list yours</Link>.
        </div>
      )}
      <div className="card divide-y divide-slate-100">
        {rows.map((r) => (
          <Link key={r.id} href={`/inbox/${r.id}`} className="flex items-center gap-3 p-4 hover:bg-slate-50">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-brand-100 font-bold text-brand-700">
              {r.other_name[0]}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex justify-between gap-2">
                <span className="font-semibold">{r.other_name}</span>
                <span className="text-xs text-slate-500">{r.i_am_seller ? "Buyer" : "Seller"}</span>
              </div>
              <div className="text-xs text-slate-500">{r.complex} · ${r.rent_monthly}/mo</div>
              <div className={`truncate text-sm ${r.unread ? "font-semibold text-slate-900" : "text-slate-600"}`}>{r.last_body ?? "No messages yet"}</div>
            </div>
            {r.unread > 0 && <span className="rounded-full bg-brand-600 px-2 text-xs font-bold text-white">{r.unread}</span>}
          </Link>
        ))}
      </div>
    </div>
  );
}
