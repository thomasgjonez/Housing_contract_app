import Link from "next/link";
import { filterChips, filtersToQuery, type Filters } from "@/lib/filters";

export function FilterBar({ filters, view, count }: { filters: Filters; view: "match" | "map"; count: number }) {
  const q = filtersToQuery(filters);
  const chips = filterChips(filters);
  const other = view === "match" ? "map" : "match";
  return (
    <div className="mb-4 flex flex-wrap items-center gap-2">
      <span className="text-sm font-semibold">{count} {count === 1 ? "listing" : "listings"}</span>
      {chips.length === 0 ? <span className="chip">No filters</span> : chips.map((c) => <span key={c} className="chip">{c}</span>)}
      <div className="ml-auto flex gap-2">
        <Link href={`/find?${q}&view=${view}`} className="btn-ghost !py-1.5">Edit filters</Link>
        <Link href={`/${other}${q ? `?${q}` : ""}`} className="btn-ghost !py-1.5">{other === "map" ? "Map view" : "Swipe view"}</Link>
      </div>
    </div>
  );
}
