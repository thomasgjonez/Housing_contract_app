# Provo Contracts

A marketplace for Provo students to sell or sublease housing contracts: a swipe matcher, a map, a "list your contract" form, and in-app messaging. It runs locally on your machine.

## Run it

Needs Node.js 22 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:3000. To try it on your phone, connect to the same Wi-Fi and open `http://<your-mac's-IP>:3000` (find the IP in System Settings > Wi-Fi > Details).

The first time it starts, it creates `data/app.db` (SQLite) with 10 Provo complexes and 12 **sample** listings so the matcher and map aren't empty. Uploaded photos go in `data/uploads/`.

- **The first account you sign up becomes the admin.** The Admin page lets you fix complex map pins, edit complex details, and delete all sample listings.
- `npm run reset-db` deletes the database so the next start reseeds it.

## Buyer matching (new in v1.1)

Sellers are plentiful and buyers are picky, so buyers fill out a profile once and the site does the matching.

- **Buyer profile** (`/profile`, or "Get matched" on the home page): the same questions as the Google Form. Dealbreakers (men's/women's, BYU-approved, budget, private or shared room, move-in date and flexibility, area, parking, pets, complexes to avoid, must-have furnished or utilities) hide listings that won't work.
- **Ranking**: everything left gets a 0–100 score from the nice-to-haves: price under budget (25), distance to campus (20), move-in timing (15), contract length or semesters (10), favorite complexes (10), and furnished, washer/dryer, utilities and private bathroom (5 each). Complexes a buyer has already swiped right on get a small boost. Each card shows its % match and the top reasons.
- **Swipe / Grid toggle** on the Match tab. Both use the same profile or filters and the same likes: a right swipe and a ♥ in the grid land in the same Saved list. The grid sorts by match, price, walk or move-in date.
- **New listings are matched automatically.** When a listing is posted (or set back to Active), it's checked against every active buyer. The seller sees how many buyers it fits; buyers scoring 70+ get an alert and a "New" badge.
- **Alerts are stubbed.** No email or text service is connected, so alerts are saved to an outbox (Admin → Buyers and matching) and printed in the terminal. Connect a provider in `src/lib/notify.ts`.
- **Import your Google Form responses**: Admin → Buyers and matching → upload the responses sheet as CSV. Re-importing updates buyers by email or phone instead of duplicating them. The admin page lists every buyer with their top matches and contact info, and each listing page shows admins which buyers fit it.
- The quick search (`/find`) still works for people without a profile, through the same matcher.

Existing databases are upgraded in place on start (new listing fields default to furnished, on-site laundry, shared bath, no pets). A fresh database also gets 4 sample buyers, removed with "Delete all samples".

The matching rules are in `src/lib/matching.ts`; weights are at the top of the file.

## What's where

| Page | File |
| --- | --- |
| Home | `src/app/page.tsx` |
| Filter quiz | `src/app/find/page.tsx` |
| Match (swipe and grid) | `src/app/match/` |
| Buyer profile | `src/app/profile/` |
| Admin: buyers, import, alert outbox | `src/app/admin/buyers/` |
| Map | `src/app/map/` (Leaflet + OpenStreetMap tiles) |
| Listing detail | `src/app/listings/[id]/` |
| List your contract | `src/app/sell/` |
| Inbox and chat | `src/app/inbox/` |
| My listings and saved | `src/app/me/page.tsx` |
| Admin | `src/app/admin/` |

Logic lives in `src/lib/`: `db.ts` (schema), `seed.ts` (sample data), `matching.ts` (dealbreakers and scoring), `buyers.ts` (profiles and new-listing matching), `notify.ts` (alerts), `formImport.ts` (Google Form CSV), `listings.ts` (listing queries), `filters.ts`, `actions.ts` (every form and button that changes data), `auth.ts` (email and password sessions).

## Known limits of v1

- Complex map pins are approximate until fixed on the Admin page, and BYU-approved flags should be checked.
- Walk times are estimated from straight-line distance to the middle of campus.
- Messages refresh every 4 seconds. Match alerts are stubbed (saved to an outbox, not sent) until an email or text provider is connected.
- No password reset and no email verification. A BYU or UVU email gets a "Student" badge without being verified.
- Built for one machine. Hosting it online (and moving SQLite to Postgres) is the v2 step.
